package FileHandling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadDataAndWriteData {

	public static void main(String[] args) throws IOException {
      /*File file=new File("C:\\Users\\hp\\Downloads");
      File[] fr=file.listFiles();
      for(File numberoffile:fr) {
    	  System.out.println(numberoffile.getName());
      }*/
		File file=new File("C:\\Users\\hp\\Desktop\\yesterday.txt");
		FileReader fr=new FileReader(file);
		BufferedReader br=new BufferedReader(fr);
		String[] line=new String[10];
	   // String line;
		for(int i=0;i<=5;i++) {
		//while(br.readLine()!=null) {
		line[i]=br.readLine();
		System.out.println(line[i]);
		}
		br.close();
		fr.close();
		FileWriter fw=new FileWriter("C:\\\\Users\\\\hp\\\\Desktop\\\\today.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		for(int i=0;i<=5;i++) { 
		 bw.write(line[i]);
		 bw.newLine();
		}
		 bw.close();
		 fw.close();
	}
}
