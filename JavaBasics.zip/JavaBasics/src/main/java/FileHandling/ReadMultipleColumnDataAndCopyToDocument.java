package FileHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadMultipleColumnDataAndCopyToDocument {

	public static void main(String[] args) throws InvalidFormatException, IOException {
		File file=new File("C:\\\\Users\\\\hp\\\\Documents\\\\day time work table.xlsx");
		XSSFWorkbook wb=new XSSFWorkbook(file);
		XSSFSheet sheet=wb.getSheet("sheet1");
		int row=sheet.getLastRowNum();
        System.out.println("Rowcount="+row);
        short colum=sheet.getRow(2).getFirstCellNum();
        System.out.println("firstcolumcountstarts="+colum);
        short colum1=sheet.getRow(2).getLastCellNum();
        System.out.println("Lastcolumcountstarts="+colum1);
        String [][]celldata=new String[row][colum1];
        for(int i=0;i<=row-1;i++) {
        for(int j=0;j<=colum1-1;j++) {
        try {
        celldata[i][j]=sheet.getRow(i).getCell(j).getStringCellValue();
        System.out.println(celldata[i][j]);
        }catch(Exception e) {
        	System.out.println("no data");
        	
        }
        }
        System.out.println('\n'+"&&&&&&&&&&&&&&&&&&&&&&"); 
        }
        wb.close();
        
        File file2=new File("C:\\Users\\hp\\Desktop\\ExcelSavedDataAfterAutomation\\copyofdaytimeworktabel.xlsx");
        FileInputStream fis=new FileInputStream(file2);
        XSSFWorkbook wb1=new XSSFWorkbook(fis);
        XSSFSheet sh=wb1.getSheet("sheet1");
        for(int i=0;i<=row-1;i++) {
        	for(int j=0;j<=colum1-1;j++) {
        	try{
        		sh.getRow(i).createCell(j).setCellValue(celldata[i][j]);
        		}catch(Exception e) {
        		System.out.println("some cells are empty its ok");
        	}
        	}
        
	}
        FileOutputStream fos=new FileOutputStream(file2);
    	wb1.write(fos);
    	wb1.close();
	}
	}
