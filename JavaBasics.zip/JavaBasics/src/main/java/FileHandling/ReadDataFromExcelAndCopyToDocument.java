package FileHandling;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadDataFromExcelAndCopyToDocument {
    //public static String celldata[];
	public static void main(String[] args) throws InvalidFormatException, IOException {
	 
	File file=new File("C:\\Users\\hp\\Documents\\day time work table.xlsx");
    XSSFWorkbook wb=new XSSFWorkbook(file);
    XSSFSheet sheet=wb.getSheet("sheet1");
    int row=sheet.getPhysicalNumberOfRows();
    System.out.println("row="+row);
    int cell=sheet.getRow(2).getPhysicalNumberOfCells();
    System.out.println("cell="+cell);
    
    String celldata[]=new String[row];
    for(int i=0;i<=row-1;i++) {
    try{
        celldata[i]= sheet.getRow(i).getCell(3).getStringCellValue();
        System.out.println("celldata="+celldata);
    	}catch(Exception e) {
    	System.out.println(e); 
     }
     }
    wb.close();
    
    File today=new File("C:\\Users\\hp\\Desktop\\today.txt");
    FileWriter fw=new FileWriter(today);
    BufferedWriter bw=new BufferedWriter(fw);
    for(int i=0;i<=row-1;i++) {
    try {
    bw.write(celldata[i]);
    bw.newLine();
    }catch(Exception e) {
    	System.out.println(e);
    }
    }
    bw.close();
    fw.close();
    
	}

}
