package exceptionsHandling;

public class LearnException {

	public static void main(String[] args) {
		int x=10;
		int y=0;
		int a[]= {5,6,7};
		try {
		System.out.println(x/y);
		System.out.println(a[4]);
		}
		catch(ArithmeticException e) {
			System.out.println("failed because of by zero");
		}
		/*catch(ArrayIndexOutOfBoundsException  e)
		{
			System.out.println("failed because it has only size as 2");
		}*/
		catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("last line of code");

	}

}
