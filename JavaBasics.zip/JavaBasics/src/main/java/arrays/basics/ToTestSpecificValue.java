package arrays.basics;

public class ToTestSpecificValue {
	
	
	public static int findindex(int a[],int num) {
	for(int i=0;i<=a.length-1;i++) {
		if(a[i]==num) {
			System.out.println("the index of"+num+"is ="+i);
		}
	}
	return num;
		
	}

	public static void main(String[] args) {
    int a[]= {56,78,90,67,87,69};
    findindex(a, 90);
    }
    }
