package arrays.basics;

import java.util.Scanner;

public class LargestandSmallestNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int size,temp;
        System.out.println("enter the size of array");
        size=sc.nextInt();
        int a[]=new int[size];
        for(int i=0;i<=a.length-1;i++) {
        	System.out.println("enter the values for array");
        	a[i]=sc.nextInt();
        }
        for(int i=0;i<=a.length-1;i++) {
        	for(int j=i+1;j<=a.length-1;j++) {
        	if(a[i]>a[j]) {
        	 temp=a[i];
        	 a[i]=a[j];
        	 a[j]=temp;
        	}
        }
        }
        
       System.out.println("the smallest value is="+a[0]);
       System.out.println("the largest value is="+a[a.length-1]);
        sc.close();
        }
	}


