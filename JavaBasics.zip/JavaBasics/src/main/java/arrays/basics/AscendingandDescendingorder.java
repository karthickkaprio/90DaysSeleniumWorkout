package arrays.basics;

import java.util.Scanner;

public class AscendingandDescendingorder {

	public static void main(String[] args) {
		int temp;
	 Scanner sc=new Scanner(System.in);
	 System.out.println("enter the size of the Array");
	 int size=sc.nextInt();
	 int a[]=new int[size];
	 for(int i=0;i<size;i++) {
		System.out.println("enter the values for array");
		a[i]=sc.nextInt();
	 }
	 
	/*for(int i=0;i<size;i++) {
		 for(int j=i+1;j<size;j++) {
		 if(a[i]<a[j]) {
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		 }
		 }
	 }
	 //for descending order
	 for(int i=0;i<size;i++) {
		 System.out.println(a[i]);
	 }
	 
	 System.out.println("&&&&&&&&&&&&&&&&&&&&&&");
	 
	 //for ascending order
	 for(int j=size-1;j>=0;j--){
		System.out.println(a[j]); 
	 }*/
	           //or
	 //for ascending order use operator change
	 for(int i=0;i<size;i++) {
			for(int j=i+1;j<size;j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		for(int i=0;i<size;i++) {
			System.out.println(a[i]);
		}
	//for ascending order we can use arrays.sort
		/* Arrays.sort(a);
		 for(int i=0;i<size;i++) {
			 System.out.println(a[i]);
		 }*/
	//for descending order we can use collections.reverse
	
	 
	sc.close();
	 
	}
}
