package arrays.basics;

import java.util.Scanner;

public class AdditonOfTwoMatrix {

	public static void main(String[] args) {
	  Scanner sc=new Scanner(System.in);
	  int size,size1;
	  System.out.println("enter the first size of first matrix ");
	  size=sc.nextInt();
	  System.out.println("enter the second size of first matix");
	  size1=sc.nextInt();
	  int sum[][]=new int[10][10];
	  int a[][]=new int[size][size1];
	  for(int i=0;i<=a.length-1;i++) {
	  for(int j=0;j<=a.length-1;j++) {
		  System.out.println("enter the element for a[i="+i+"]a[j="+j+"]first matrix");
		  a[i][j]=sc.nextInt();
		  }
	  }
	  int si,si1;
	  System.out.println("enter the first size of second matrix ");
	  si=sc.nextInt();
	  System.out.println("enter the second size of second matix");
	  si1=sc.nextInt();
	  int b[][]=new int[si][si1];
	  for(int i=0;i<=b.length-1;i++) {
		  for(int j=0;j<=b.length-1;j++) {
			  System.out.println("enter the element for b[i="+i+"]b[j="+j+"]second matrix");
			  b[i][j]=sc.nextInt();
			  }
		  }
	  for(int i=0;i<=a.length-1;i++) {
	  for(int j=0;j<=a.length-1;j++) {
	     sum[i][j]=a[i][j]+b[i][j];
	     System.out.println(sum[i][j]);
	  }
	  }
	  sc.close();
	}   
}
