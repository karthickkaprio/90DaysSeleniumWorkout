package arrays.basics;

import java.util.Scanner;

public class ToInsertSpecificPosition {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the size of an array");
	int size=sc.nextInt();
    int a[]=new int [size];
    for(int i=0;i<=a.length-1;i++) {
    System.out.println("enter the value for=a["+i+"]");
    a[i]=sc.nextInt();
	}
    for(int j=0;j<=a.length-1;j++) {
    System.out.println("entered the value as for=a["+j+"]"+" "+a[j]);
	}
    System.out.println("enter the element to be inserted=");
    int ele=sc.nextInt();
    System.out.println("enter the element to be inserted at position=");
    int pos=sc.nextInt();
    
    for(int i=0;i<=a.length-1;i++) {
    	if(pos-1==i) {
    	a[i]=ele;
    	System.out.println("the values inserting="+a[i]);
    	}
    	System.out.println("the values inserted after in="+a[i]);
    	}
    sc.close();
}
}
