package arrays.basics;

public class SumValuesOfANArray {

	public static void main(String[] args) {
		int a[]= {26,89,68,78};
	
		int count=2,val=0,sum=0;
		
		for(int i=0;i<=count;i++) {
		val=a[i]+a[i+1];
		sum+=val;
		i++;
		}
		System.out.println(sum);
		}
	}
