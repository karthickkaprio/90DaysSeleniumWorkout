package arrays.basics;

import java.util.Arrays;

public class Sorting {

	public static void main(String[] args) {
    int a[]= {1,2,3,4,5,9,8,7,6};
    String b[]={"karthick","kaprio","pandian","crassy","master"};
    
    System.out.println("the values before sorting"+Arrays.toString(a));
    Arrays.sort(a);
    System.out.println("the values after sorted"+Arrays.toString(a));
    Arrays.sort(b);
    System.out.println(Arrays.toString(b));
	}
}
