package arrays.basics;

public class CalculateAverage {

	public static void main(String[] args) {
		int a[]= {10,20,30,40,50};
		
		int val=0,sum=0,count=2;
		for(int i=0;i<=count;i++) {
			val=a[i]+a[i+1];
			sum+=val;
			i++;
			}
			count=(sum+a[4])/a.length;
			System.out.println(count);
		}
}

