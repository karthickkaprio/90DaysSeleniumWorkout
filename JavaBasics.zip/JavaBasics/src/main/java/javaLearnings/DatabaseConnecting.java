package javaLearnings;

public class DatabaseConnecting {

	
	public static void main(String[] args) {
	  
	}

}
