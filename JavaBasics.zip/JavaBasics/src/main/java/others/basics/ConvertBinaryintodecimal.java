package others.basics;

import java.util.Scanner;

public class ConvertBinaryintodecimal {

	public static void main(String[] args) {
		double pow,bin,sum=0,dec=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the binary number");
		 bin=sc.nextDouble();
		 
        for(int i=0;i<=bin;i++) {
        	bin=bin/10;
        	pow=bin%10;
        	System.out.println(pow);
        	/*sum=(2^pow);
        	System.out.println(sum);
        	dec+=sum;*/
        	}
        //System.out.println(dec);
        sc.close();
	}

}
