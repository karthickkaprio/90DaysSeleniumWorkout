package others.basics;

public class FindAreaandCircumference {
	
	
	public static  double Area(int rad) {
		double area;
		area=3.14*rad*rad;
	    return area;
	    }
	
	public static  double Circum(int rad) {
			double circum;
			circum=2*3.14*rad;
			return circum;
		}

	public static void main(String[] args) {
		
		/*Scanner sc=new Scanner(System.in);
        System.out.println("enter the radius of the circle");
        int rad=sc.nextInt();
        double Area=3.14*rad*rad;
        double circum=2*3.14*rad;
        System.out.println("Area of the circle is="+Area);
        System.out.println("Circumference of the circle is="+circum);
        sc.close();*/
		//for non static methods object creation must
		//FindAreaandCircumference ac=new FindAreaandCircumference();
      /* double res=ac.Area(5);
       System.out.println("Area="+res);
       double res1=ac.Circum(5);
       System.out.println("Circum="+res1);*/
		//for static method no need object creation
		double area1=Area(5);
		System.out.println("Area="+area1);
		double circum1=Circum(5);
		System.out.println("circum="+circum1);
	}

}
