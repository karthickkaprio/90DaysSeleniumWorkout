package others.basics;

public class FindExponent {
	
	public static float exponent(int num,int exp) {
	 float temp=1,sum=1;
	 for(int i=1;i<exp;i++) {
		temp=temp*num/i;
		sum=sum+temp;
	 }
	 return sum;
	}

	public static void main(String[] args) {
		/*Scanner sc =new Scanner(System.in);
		float num,temp=1,sum=1;
        System.out.println("enter the number");
        num=sc.nextInt();
        System.out.println("enter the exponent value");
        int exp=sc.nextInt();
        for(int i=1;i<exp;i++) {
        	temp=temp*num/i;
        	sum=sum+temp;
        }
        System.out.println(sum);
        sc.close();*/
		float exp=exponent(5,5);
		System.out.println(exp);
	}

}
