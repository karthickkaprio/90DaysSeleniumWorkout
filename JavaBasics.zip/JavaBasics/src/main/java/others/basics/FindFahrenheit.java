package others.basics;

public class FindFahrenheit {
	
	public static double faren(int celsius) {
		double farenheit;
		farenheit=(1.8*celsius)+32;
		return farenheit;
		
	}

	public static void main(String[] args) {
		/*Scanner sc=new Scanner(System.in);
		System.out.println("enter the celsius value");
		int celsius=sc.nextInt();
		double fahrenheit=(1.8*celsius)+32;
		System.out.println(fahrenheit);
		sc.close();
*/
		double far=faren(45);
		System.out.println(far);
	}

}
