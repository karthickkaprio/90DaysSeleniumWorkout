package oct.week2;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date14 {

	public static void main(String[] args) throws InterruptedException, AWTException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://imgbb.com/");//("https://id.atlassian.com/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//hari.radhakrishnan@testleaf.com
		
       /* driver.findElementById("username").sendKeys("hari.radhakrishnan@testleaf.com");
        driver.findElementById("login-submit").click();
        Thread.sleep(2000);
        driver.findElementByXPath("//input[@id='password']").sendKeys("India@123");
        driver.findElementById("login-submit").click();
        Thread.sleep(10000);
        
        WebElement rest=driver.findElementByXPath("//div[@data-test-id='collab-graph-container-row']//a[1]");
        WebDriverWait wt =new WebDriverWait(driver,20);
        wt.until(ExpectedConditions.elementToBeClickable(rest));
        JavascriptExecutor executor=(JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", rest);
        
        WebElement backlog=driver.findElementByXPath("(//div[@class='css-1oyzili'])[3]");
        WebDriverWait wait =new WebDriverWait(driver,20);
        wait.until(ExpectedConditions.elementToBeClickable(backlog));
        backlog.click();
        String issues=driver.findElementByXPath("(//div[@class='header-left'])[2]//div[3]").getText();
        String count=issues.replaceAll("\\D", "");
        System.out.println("issues Count="+count);
        driver.findElementByXPath("(//div[@class='iic iic-agile-plan']//button)[1]").click();
        driver.findElementByXPath("(//div[@class='iic-widget__footer']//span)[2]").click();
        Thread.sleep(4000);
        driver.findElementByXPath("//label[@for='summary']/following::input[1]").sendKeys("Story created by karthick");
        driver.findElementByXPath("//button[text()=' browse.']").click();
        Thread.sleep(4000);
        WebElement fr=driver.findElementByXPath("//iframe[@class='mpApp']");
        driver.switchTo().frame(fr);
        driver.findElementByXPath("(//div[@id='app']//button)[1]").click();
        Thread.sleep(5000);
        System.out.println("Robot action");*/
        driver.findElementByXPath("//div[@class='home-buttons']/a").click();
        Thread.sleep(3000);
        //Robot robot=new Robot();
        StringSelection ss=new StringSelection("‪‪‪C:\\Users\\hp\\Desktop\\IMG-20200723-WA0008.jpg");
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
        Robot robot=new Robot();
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyRelease(KeyEvent.VK_V);
        
        
        Thread.sleep(4000);
        
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        
        System.out.println("Robot action done");
        
        
        
        
        
        
        
        
        
        
        
        
        
	}

}
