package oct.week2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date12 {

	public static void main(String[] args) throws InterruptedException {
    WebDriverManager.chromedriver().setup();
    ChromeDriver driver=new ChromeDriver();
    driver.get("https://www.bigbasket.com/");
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    WebElement hover=driver.findElementByXPath("(//div[@id='navbar']//a)[1]");
    Actions builder=new Actions(driver);
    builder.moveToElement(hover).perform();
    WebElement hover1=driver.findElementByXPath("(//div[@id='navbar']//a)[3]");
    Actions builder1=new Actions(driver);
    builder1.moveToElement(hover1).perform();
    driver.findElementByXPath("(//div[@id='navbar']//a)[15]").click();
    Thread.sleep(2000);
    driver.findElementByXPath("(//i[@class='cr-icon fa fa-check']/following::span)[5]").click();
    Thread.sleep(2000);
    driver.findElementByXPath("(//span[@ng-bind='brand.display_name'])[3]").click();
    Thread.sleep(3000);
    WebElement ponni=driver.findElementByXPath("//a[contains(text(),'Ponni Boiled Rice - Super Premium')]/parent::div");
    Actions builder2=new Actions(driver);
    builder2.moveToElement(ponni).perform();
    Thread.sleep(5000);
    driver.findElementByXPath("(//a[contains(text(),'Ponni Boiled Rice - Super Premium')]/following::button)[1]").click();
    Thread.sleep(2000);
    driver.findElementByXPath("(//a[contains(text(),'Ponni Boiled Rice - Super Premium')]/following::a)[1]").click();
    String price=driver.findElementByXPath("(//a[contains(text(),'Ponni Boiled Rice - Super Premium')]/following::span)[16]").getText();
    System.out.println("the price of rice is="+price);
    driver.findElementByXPath("(//a[contains(text(),'Ponni Boiled Rice - Super Premium')]/following::button)[2]").click();
    
    //
    WebElement citymess=driver.findElementByXPath("//a[@qa='areaDD']");
    
    boolean flash=new WebDriverWait(driver,10).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='toast toast-success']/div")));
    if(flash==true) {
    	System.out.println("there is no flash message");
    }
    else {
    	String notification=driver.findElementByXPath("//div[@class='toast toast-success']/div").getText();
    	System.out.println(notification);
    }
    
    new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(citymess));
    
    //
    
    
   
    
    driver.findElementByXPath("(//div[@class='input-group']//input)[1]").sendKeys("dal",Keys.ENTER);
    Thread.sleep(2000);
    WebElement dal= driver.findElementByXPath("(//div[@qa='product'])[2]");
    Actions builder3=new Actions(driver);
    builder3.moveToElement(dal).perform();
    driver.findElementByXPath("(//span[@ng-if='!product.attrs.type']//button)[2]").click();
    Thread.sleep(1000);
    driver.findElementByXPath("(//ul[@class='dropdown-menu drop-select']//li)[5]").click();
    WebElement quantity=driver.findElementByXPath("(//div[@qa='qty']//input)[2]");
    quantity.clear();
    quantity.sendKeys("2");
    String dalprice=driver.findElementByXPath("((//div[@qa='price'])[2]//span)[5]").getText();
    System.out.println("the price of dal is="+dalprice);
    driver.findElementByXPath("(//button[@qa='add'])[2]").click();
    Thread.sleep(10000);
    WebElement basket=driver.findElementByXPath("//a[@qa='myBasket']");
    builder3.moveToElement(basket).perform();
    Thread.sleep(2000);
    String subtotal=driver.findElementByXPath("(//div[@class='row sub-cost ng-scope']//span)[1]").getText();
    System.out.println("subtotal="+subtotal);
    
    if(subtotal.equals("Rs 835.00")) {
    	System.out.println("yes total is correct as per product value");
    	System.out.println("iam gonna reduce the dool quantity");
    }
    else {
    	System.out.println("total of the product is not matching");
    }
    driver.findElementByXPath("(//div[@class='btn-counter row']/button)[3]").click();
    Thread.sleep(2000);
    
    String redsubtotal=driver.findElementByXPath("(//div[@class='row sub-cost ng-scope']//span)[1]").getText();
    System.out.println("subtotal="+redsubtotal);
    
    if(redsubtotal.equals("Rs 575.00")) {
    	System.out.println("now it is matching with the subtotal after reducing");
    }
    else {
    	System.out.println("no it is not matching with the subtotal after reduced");
    }
	}

}
