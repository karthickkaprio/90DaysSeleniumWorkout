package oct.week2;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date13 {
 public static String data,data1,price;
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://store.hp.com/in-en/default/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='inside_visitorNotify']/div)[1]")));
		driver.findElementByXPath("(//div[@class='optanon-alert-box-wrapper  ']//button)[3] ").click();
		WebElement laptop=driver.findElementByXPath("//a[@id='ui-id-2']/span");
        Actions builder=new Actions(driver);
        builder.moveToElement(laptop).perform();
        driver.findElementByXPath("//a[@id='ui-id-44']/span").click();
        Thread.sleep(4000);
        driver.findElementByXPath("(//div[@data-title='Processor']//span)[1]").click();
        Thread.sleep(4000);
        driver.findElementByXPath("(//div[@data-title='Hard Drive Capacity']//a)[2]").click();
        Thread.sleep(4000);
        driver.findElementByXPath("(//div[@data-title='Memory standard']//a)[1]").click();
        Thread.sleep(4000);
        String name=driver.findElementByXPath("//strong[@class='product name product-item-name']/a").getText();
	  
        System.out.println("Productname="+name);
	    price=driver.findElementByXPath("(//div[@class='price-box']//span)[4]").getText();
	    
	    System.out.println("productprice="+price);
	    driver.findElementByXPath("//form[@data-role='tocart-form']//button").click();
	    Thread.sleep(4000);
	    driver.findElementByXPath("//div[@data-block='minicart']/a").click();
	    Thread.sleep(4000);
	    driver.findElementByXPath("(//div[@class='actions'])[2]//span").click();
	    Thread.sleep(5000);
	    WebElement pinbox=driver.findElementByXPath("//div[@id='product-deliver']//input");
	    pinbox.clear();
	    pinbox.sendKeys("600028");
	    driver.findElementByXPath("//div[@id='product-deliver']//button").click();
	    Thread.sleep(2000);
	    WebElement box=driver.findElementByXPath("//div[@id='cart-totals']//table");
	    List<WebElement> row=box.findElements(By.tagName("tr"));
	    List<WebElement> columndata=driver.findElements(By.tagName("td"));
	    for(int i=0;i<row.size();i++) {
	    	 data=columndata.get(0).getText();
	    	 //System.out.println("data="+data);
	    	 data1=columndata.get(2).getText();
	    	 //System.out.println("data1="+data1);
	    }
	    	 if(data.equals(data1)) {
	    		 System.out.println("yes ordertotal and subtotal matches");
	    	 }
	    	 if(price.equals(data1)) {
	    		 System.out.println("yes productprice and ordertotal matches");
	    	 }
	    	 else {
	    		 System.out.println("no ordertotal and subtotal doesnt match");
	    		 System.out.println("no productprice and ordertotal doesnt match");
	    		 
	    	 }
	    	 
	    driver.findElementByXPath("(//button[@id='sendIsCAC'])[1]").click();
	    Thread.sleep(15000);
	    driver.findElementByXPath("(//button[@type='button'])[5]").click();
	    String error=driver.findElementByXPath("(//fieldset[@id='customer-email-fieldset']//div)[3]").getText();
	    System.out.println("error message="+error);
	}

}
