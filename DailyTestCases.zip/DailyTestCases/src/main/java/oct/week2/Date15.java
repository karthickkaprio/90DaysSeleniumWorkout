package oct.week2;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date15 {
   

	public static void main(String[] args) throws InterruptedException {
	   WebDriverManager.chromedriver().setup();
	   ChromeDriver driver=new ChromeDriver();
	   
	   driver.get("https://www.honda2wheelersindia.com/");
	   driver.manage().window().maximize();
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   WebElement close=driver.findElementByXPath("(//button[@type='button'])[2]");
	   WebDriverWait wait=new WebDriverWait(driver,60);
	   wait.until(ExpectedConditions.visibilityOfAllElements(close));
	   close.click();
	   driver.findElementByXPath("(//div[@id='nivel-1']//a)[2]").click();
	   driver.findElementByXPath("(//div[@id='scooter']//a/img)[1]").click();
	   Thread.sleep(2000);
	   driver.findElementByXPath("(//div[@id='accordion-1']//a)[4]").click();
	   WebElement engine=driver.findElementByXPath("(//ul[@class='specifications']//a)[2]");
	   Actions builder=new Actions(driver);
	   builder.moveToElement(engine).perform();
	   String diodisp=driver.findElementByXPath("(//div[@class='engine part-2 axx']//span)[5]").getText();
	   String dd=diodisp.replaceAll("\\D","");
	   System.out.println("dioDisp="+dd);
	   Thread.sleep(10000);
	   driver.findElementByXPath("(//div[@id='nivel-1']//a)[2]").click();
	   Thread.sleep(10000);
	   driver.findElementByXPath("(//div[@id='scooter']//a/img)[2]").click();
	   Thread.sleep(2000);
	   driver.findElementByXPath("(//div[@id='accordion-1']//a)[4]").click();
	   WebElement engine1=driver.findElementByXPath("(//ul[@class='specifications']//a)[2]");
	   Actions builder1=new Actions(driver);
	   builder1.moveToElement(engine1).perform();
	   String Activadisp=driver.findElementByXPath("(//div[@class='engine part-2 axx']//span)[5]").getText();
	   String ad=Activadisp.replaceAll("\\D","");
	   System.out.println("Activadisp="+ad);
	   if(dd.equals(ad)) {
		   System.out.println("both the bike dio and activa are having same displacement");
	   }
	   driver.findElementByXPath("(//ul[@class='nav navbar-nav']/li/a)[10]").click();
	   //WebDriverWait wait1=new WebDriverWait(driver, 30);
	   WebElement activa125=driver.findElementByXPath("((//div[@id='style-3']/div)[2]/a)[11]");
	  // wait1.until(ExpectedConditions.elementToBeClickable(activa125));
	   //activa125.click();
	   
	   JavascriptExecutor exe=(JavascriptExecutor)driver;
	   exe.executeScript("arguments[0].click();", activa125);
	   Thread.sleep(5000);
	   WebElement vehicleprice=driver.findElementByXPath("//li[@id='li6']/a");
	   JavascriptExecutor executor = (JavascriptExecutor)driver;
	   executor.executeScript("arguments[0].click();", vehicleprice);
	   WebElement box1=driver.findElementByXPath("(//select[@name='ModelID'])[6]");
	   Select st=new Select(box1);
	   st.selectByValue("31");
	   driver.findElementByXPath("//button[@id='submit6']").click();
	   
	   //inga tabel la normal method use pannen click ahala elementclickinterceptedexception varuthu
	   //so javascript executor use paniten
	   //WebElement tb=driver.findElementByXPath("//div[@id='divPriceMasterResult']//table");
	   //List<WebElement> row=tb.findElements(By.tagName("tr"));
	   //List<WebElement> colum=tb.findElements(By.tagName("td"));
	   Thread.sleep(2000);
	   WebElement text2=driver.findElementByXPath("(//a[@target='_blank'])[11]");
	   JavascriptExecutor executor1 = (JavascriptExecutor)driver;
	   executor1.executeScript("arguments[0].click();", text2);
	   //colum.get(2).click();
	   Set<String> window=driver.getWindowHandles();
	   List<String> win=new ArrayList<String>(window);
	   String parentwindow=win.get(0);
	   System.out.println(parentwindow);
	   String childwindow=win.get(1);//select[@id='CityID']
	   System.out.println(childwindow);
	   driver.switchTo().window(childwindow);
	   Thread.sleep(10000);
	   WebElement state=driver.findElementByXPath("//select[@id='StateID']");
	   Select st1=new Select(state);
	   st1.selectByValue("28");
	   WebElement city=driver.findElementByXPath("//select[@id='CityID']");
	   Select st2=new Select(city);
	   st2.selectByVisibleText("Chennai");
	   Thread.sleep(2000);
	   driver.findElementByXPath("(//button[@type='button'])[2]").click();
	   WebElement tb1=driver.findElementByXPath("//table[@id='gvshow']");
	   //List<WebElement> row1=tb1.findElements(By.tagName("tr"));
	   List<WebElement> column1=tb1.findElements(By.tagName("td"));
	   for(int i=1;i<=column1.size()-1;i++) {
		   String firstcolumn=column1.get(i).getText();
           String secondcolumn=column1.get(i+1).getText();
           System.out.println(firstcolumn+"  "+secondcolumn);
           i++;
	   }
	   Thread.sleep(2000);
	   driver.close();
	   driver.switchTo().window(parentwindow);
	   Thread.sleep(2000);
	   driver.close();
	   }
}

	   


