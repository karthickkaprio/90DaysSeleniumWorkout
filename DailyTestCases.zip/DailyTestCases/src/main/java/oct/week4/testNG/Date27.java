package oct.week4.testNG;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date27 {
    @Test
	public void runjustdial() throws InterruptedException, IOException {
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		    
	    WebDriverManager.chromedriver().setup();
	    ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.justdial.com/Chennai/Car-Repair-Services-Hyundai-Accent-in-Porur/nct-10961775");//("https://www.justdial.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 
	/*	
		driver.findElementByXPath("//div[@class='search-city mnsrchwpr']").click();
		driver.findElementByXPath("//ul[@id='cuto']/li[4]").click();
		driver.findElementByXPath("//ul[@id='sidebarnavleft']/li[8]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//ul[@class='mm-listview mm-lstex']/li[1]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//ul[@class='mm-listview']/li[5]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//ul[@class='mm-listview']/li)[2]").click();*/
		WebDriverWait wait =new WebDriverWait(driver,120);
	    WebElement close= driver.findElementByXPath("(//section[@id='best_deal_div']//span)[1]");
	    wait.until(ExpectedConditions.elementToBeClickable(close));
	    close.click();
	    Thread.sleep(5000);
	    /*driver.findElementByXPath("//ul[@class='brdUL']/li[3]").click();
	    driver.findElementByXPath("//section[@id='jsbd']//input[1]").sendKeys("porur");
	    driver.findElementByXPath("(//ul[@id='auto']//b)[1]").click();
	    Thread.sleep(2000);*/
	    /*driver.findElementByXPath("//ul[@class='brdUL']/li[4]").click();
	    driver.findElementByXPath("//span[@class='drpwn']/a[1]").click();
	    Thread.sleep(5000);*/
	   
	   
	    int count=1;
	    for(int i=1;i<=1000;i++) {
	   // System.out.println("count="+count);
	    	File src =new File("./ExcelWrite/justdial.xlsx‪");
	    	FileInputStream fis=new FileInputStream(src);
	    	XSSFWorkbook wb=new XSSFWorkbook(fis);
	        XSSFSheet sheet=wb.getSheet("sheet1");
	        
	       
	    WebElement gb=driver.findElementByXPath("(//p[@class='newrtings ']//span)["+i+"]");
	    Actions builder=new Actions(driver);
	    builder.moveToElement(gb).perform();
	    String greenbox=gb.getText();
	    i=i+7;
	    if(greenbox.equals("")) {
	    	i=i-2;
	    greenbox="0.0";
	    }
	    float greenbox1=Float.parseFloat(greenbox);
	    //System.out.println("i="+i);
	    WebElement pv=driver.findElementByXPath("(//p[@class='newrtings ']//span)["+i+"]");
	    Actions builder1=new Actions(driver);
	    builder1.moveToElement(pv).perform();
	    String peoplevotes=pv.getText();
	    String votes=peoplevotes.replaceAll("\\D", "");
	    int vote=Integer.parseInt(votes);
	    System.out.println("greenboxRating="+greenbox+"  "+"votes="+votes);
	    sheet.getRow(count).createCell(0).setCellValue(greenbox);
	    sheet.getRow(count).createCell(1).setCellValue(votes);
	    Thread.sleep(2000);
	    if((greenbox1>=4.5)&&(vote>=50)) {
	    	String name=driver.findElementByXPath("(//h2[@class='store-name']/span)["+count+"]").getText();
	    	System.out.println("name="+name);
	    	sheet.getRow(count).createCell(2).setCellValue(name);
	    	}
	   
	    FileOutputStream fos=new FileOutputStream(src);
	    wb.write(fos);
	    wb.close();
	    
	    count=count+1;
	    if(i==778) {
	    	driver.findElementByXPath("(//div[@id='srchpagination']//a)[12]").click();
	    	Thread.sleep(5000);
	    	i=0;
	    	count=0;
	    }
	    
	    }
    }
}

	
    
	

