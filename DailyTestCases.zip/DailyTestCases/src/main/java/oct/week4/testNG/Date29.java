package oct.week4.testNG;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Date29 {
    @Test
	public void runAvis() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Downloads\\driver\\chromedriver.exe");
	  ChromeDriver driver=new ChromeDriver();
	  driver.get("https://www.avis.co.in/");
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
      ChromeOptions option=new ChromeOptions();
      option.addArguments("--disable-notifications");
      WebElement flash=driver.findElementByXPath("//div[@id='nvpush_cross']");
      WebDriverWait wait =new WebDriverWait(driver,30);
      wait.until(ExpectedConditions.elementToBeClickable(flash));
      flash.click();
      driver.findElementByXPath("//li[@class='selfdriveTab']").click();
      Thread.sleep(5000);
      WebElement city=driver.findElementByXPath("//select[@name='DrpCity']");
      Select cy=new Select(city);
      cy.selectByValue("6");
      Thread.sleep(5000);
      driver.findElementByXPath("//div[@id='div_AddPopup']/following::input[1]").sendKeys("kodambakkam");
      driver.findElementByXPath("//div[@id='div_AddPopup']/following::input[2]").click();
     /* LocalDate date = LocalDate.now();
      System.out.println("Current Date: " + date);
      String stchange=date.toString();
      startdate.click();
      Thread.sleep(2000);
      startdate.sendKeys("30-10-2020");
      Thread.sleep(2000);
      date = date.plusDays(5);
      System.out.println("Date after Increment: " + date);
      String edchange=date.toString(); */
      WebElement starttb=driver.findElementByXPath("(//div[@class='xdsoft_datepicker active']//table)[6]");
      List<WebElement> row=starttb.findElements(By.tagName("tr"));
      //System.out.println(row.size());
      for(int i=1;i<=row.size();i++) {
    	  if(i==6) {
    		  WebElement todaydate=driver.findElementByXPath("(//td[@data-date='31'])[8]");
    		  Actions builder=new Actions(driver);
    		  builder.moveToElement(todaydate).perform();
    		  todaydate.click();
    		  break;
    	  }
    	 Thread.sleep(2000);
      }
      for(int i=1;i<=47;i++) {
    	  String text=driver.findElementByXPath("(//div[@class='xdsoft_time_variant'])[6]/div["+i+"]").getText();
    	  //System.out.println("i="+i+" "+text);
    	  //Thread.sleep(500);
    	  if(text.equals("18:30")) {
    		  WebElement starttime=driver.findElementByXPath("(//div[@class='xdsoft_time_variant'])[6]/div["+i+"]");
    		  Actions builder1=new Actions(driver);
    		  builder1.moveToElement(starttime).perform();
    		  starttime.click();
    		  break;
    	  }
          }
      Thread.sleep(2000);
      WebDriverWait wait0=new WebDriverWait(driver,30);
      WebElement enddate=driver.findElementByXPath("//div[@id='div_AddPopup']/following::input[3]");
      wait0.until(ExpectedConditions.elementToBeClickable(enddate));
      enddate.click();
      //for(int j=1;j<=16;j++) {
      ///String month=driver.findElementByXPath("(//div[@class='xdsoft_mounthpicker']//span)["+j+"]").getText();
      //Thread.sleep(2000);
     // if(month.equals("November")) {
      Thread.sleep(3000);
    	  WebElement endtb=driver.findElementByXPath("(//div[@class='xdsoft_datepicker active']//table)[5]");
          List<WebElement> row1=endtb.findElements(By.tagName("tr"));
          //System.out.println(row1.size());
    	  for(int i=1;i<=row1.size();i++) {
        	  if(i==2) {
        		  WebElement todaydate=driver.findElementByXPath("(//td[@data-date='4'])[5]");
        		  Actions builder=new Actions(driver);
        		  builder.moveToElement(todaydate).perform();
        		  todaydate.click();
        		  break;
        	  }
        	 Thread.sleep(2000);
          }
          for(int i=1;i<=47;i++) {
        	  String text=driver.findElementByXPath("(//div[@class='xdsoft_time_variant'])[5]/div["+i+"]").getText();
        	 // System.out.println("i="+i+" "+text);
        	 // Thread.sleep(500);
        	  if(text.equals("18:00")) {
        		  WebElement endtime=driver.findElementByXPath("(//div[@class='xdsoft_time_variant'])[5]/div["+i+"]");
        		 // Actions builder1=new Actions(driver);
        		 // builder1.moveToElement(endtime).perform();
        		  JavascriptExecutor executor=(JavascriptExecutor)driver;
        		  executor.executeScript("arguments[0].click();", endtime);
        		  //endtime.click();
        		  break;
        	  }
    	  }
         // break;
      //}
     // driver.findElementByXPath("(//div[@class='xdsoft_datepicker active']//button)[15]").click();
      //}
         Thread.sleep(2000);
         WebElement car= driver.findElementByXPath("//select[@name='drpCars']");
         Select cr=new Select(car);
         cr.selectByVisibleText("XUV - 500");
         Thread.sleep(2000);
         driver.findElementByXPath("//div[@id='div_AddPopup']/following::input[7]").click();
         Thread.sleep(2000);
         String carname=driver.findElementByXPath("//div[@class='filling-fast']/following::h4[1]").getText();
         System.out.println("CarName="+carname);
         String availablecartext=driver.findElementByXPath("//div[@class='filling-fast']").getText();
         String availablecars=availablecartext.replaceAll("\\D", "");
         System.out.println("Avaialable cars="+availablecars);
         driver.findElementByXPath("(//div[@class='buttons']/a)[1]").click();
         Thread.sleep(5000);
         driver.findElementByXPath("(//input[@placeholder='FIRST NAME'])[1]").sendKeys("kishore");
         driver.findElementByXPath("(//input[@placeholder='LAST NAME'])[1]").sendKeys("K");
         driver.findElementByXPath("(//input[@id='txtGEmail'])[1]").sendKeys("kishore123@gmail.com");
         driver.findElementByXPath("(//input[@id='txtGMobileNo'])[1]").sendKeys("5555555555");
         Thread.sleep(5000);
         driver.findElementByXPath("(//input[@id='txtGDOB'])[1]").click();
         Thread.sleep(2000);
         driver.findElementByXPath("(//div[@class='xdsoft_label xdsoft_year'])[5]").click();
         for(int i=2;i<=105;i++) {
         
         String scroll=driver.findElementByXPath("(//div[@class='xdsoft_label xdsoft_year'])[5]//div["+i+"]").getAttribute("data-value");
         //System.out.println("scroll="+scroll);
         //String year=driver.findElementByXPath("(//div[@class='xdsoft_label xdsoft_year']/span)[5]").getText();
         if(scroll.equals("1993")) {
        	 WebElement year=driver.findElementByXPath("(//div[@class='xdsoft_label xdsoft_year'])[5]//div["+i+"]");
        	 Actions builder4 =new Actions(driver);
        	 builder4.moveToElement(year).perform();
        	 year.click();
        	for(int j=1;j<=12;j++) {
        	 String month=driver.findElementByXPath("(//div[@class='xdsoft_label xdsoft_month']/span)[5]").getText();
        	// System.out.println("month="+month);
        	 if(month.equals("July")) {
        	 WebElement dobtb=driver.findElementByXPath("(//div[@class='xdsoft_calendar'])[5]/table");
        	 List<WebElement> dbrow=dobtb.findElements(By.tagName("tr"));
        	 for(int k=0;k<=dbrow.size();k++) {
        	 if(k==4) {
        	 driver.findElementByXPath("(//td[@data-date='23'])[5]").click();
        	 break;
        	}
        }
        	 break;
       }
        driver.findElementByXPath("(//div[@class='xdsoft_label xdsoft_year'])[5]/following::button[1]").click();
        Thread.sleep(500);
      }
        	break;
	}
}
         Thread.sleep(2000);
         driver.findElementByXPath("(//input[@type='submit'])[8]").click();
         Thread.sleep(5000);
         driver.findElementByXPath("//input[@placeholder='Aadhaar Card number']").sendKeys("1111222233334444");
         ChromeOptions option1=new ChromeOptions();
         option1.addArguments("--disable-notifications");
        
         WebElement checkbox=driver.findElementByXPath("(//div[@id='divadon']//input)[1]");
         JavascriptExecutor executor=(JavascriptExecutor)driver;
		 executor.executeScript("arguments[0].click();", checkbox);
         Thread.sleep(2000);
         
         WebElement checkbox2=driver.findElementByXPath("(//div[@id='divadon']//input)[2]");
         JavascriptExecutor executor1=(JavascriptExecutor)driver;
		 executor1.executeScript("arguments[0].click();", checkbox2);
         Thread.sleep(2000);
         
         WebElement checkbox3=driver.findElementByXPath("(//div[@id='divadon']//input)[3]");
         JavascriptExecutor executor3=(JavascriptExecutor)driver;
		 executor3.executeScript("arguments[0].click();", checkbox3); 
         Thread.sleep(2000);
         
         WebElement agree=driver.findElementByXPath("//div[@class='col-sm-3 chk']//input");
         JavascriptExecutor executor4=(JavascriptExecutor)driver;
		 executor4.executeScript("arguments[0].click();", agree);
         Thread.sleep(4000);
         driver.findElementByXPath("//div[@class='verification']/div").click();
         Thread.sleep(5000);
         
         String total=driver.findElementByXPath("(//div[@class='booking-revised-sm']//strong//span)[2]").getText();
         System.out.println("Total Amount="+total);
         String colour=driver.findElementByXPath("//a[text()='Confirm Booking']").getCssValue("background");
         System.out.println("colour="+colour);
         Thread.sleep(2000);
         driver.close();
	}
}
