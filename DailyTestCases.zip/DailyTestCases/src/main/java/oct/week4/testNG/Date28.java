package oct.week4.testNG;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Date28 {
    @Test
	public void runMicrosoft() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Downloads\\driver\\chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://azure.microsoft.com/en-us/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//button[@id='navigation-pricing']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//ul[@id='pricing-menu']/li)[3]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='category-list']/div[7]/button").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//button[@title='Container Instances'])[2]").click();
		Thread.sleep(2000);
		WebDriverWait wait=new WebDriverWait(driver,10);
		WebElement popup=driver.findElementByXPath("//div[@role='status']//button");
		wait.until(ExpectedConditions.elementToBeClickable(popup));
		popup.click();
		Thread.sleep(2000);
		WebElement region=driver.findElementByXPath("//select[@name='region']");
		Select re=new Select(region);
		re.selectByValue("south-india");
		Thread.sleep(2000);
		driver.findElementByXPath("(//div[@class='wa-textNumber']/input)[2]").sendKeys("180000");
		Thread.sleep(2000);
		WebElement memory=driver.findElementByXPath("//select[@name='memory']");
		Select me=new Select(memory);
		me.selectByValue("4");
		Thread.sleep(2000);
		driver.findElementByXPath("(//div[@class='calculator-toggler ']//button)[1]").click();
		Thread.sleep(2000);
		WebElement rupee=driver.findElementByXPath("//select[@class='select currency-dropdown']");
		Select ru=new Select(rupee);
		ru.selectByValue("INR");
		Thread.sleep(2000);
		String price=driver.findElementByXPath("(//span[@class='numeric']/span)[6]").getText();
		System.out.println("Estimated Monthly Price="+price);
		driver.findElementByXPath("(//div[@class='column large-6 calculator-actions']/button)[1]").click();
		Thread.sleep(2000);
		File file=new File("C:\\Users\\hp\\Downloads");
		File[] fl=file.listFiles();
		for(File numberoffile:fl) {
			if(numberoffile.getName().equalsIgnoreCase("ExportedEstimate.xlsx")) {
				System.out.println("yes directory has the file with the above name");
				break;
			}
		}
		WebElement example=driver.findElementByXPath("//li[@id='solution-architectures-picker']");
		Actions builder1=new Actions(driver);
		builder1.moveToElement(example).perform();
		example.click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//section[@id='solution-architectures-picker-panel']//button)[3]").click();
		Thread.sleep(2000);
		WebElement addbutton=driver.findElementByXPath("//button[text()='Add to estimate']");
		//Actions builder2=new Actions(driver);
		//builder2.moveToElement(example).perform();
		//addbutton.click();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", addbutton);
		Thread.sleep(5000);
		WebElement containerrupee=driver.findElementByXPath("//select[@class='select currency-dropdown']");
		Select cr=new Select(containerrupee);
		cr.selectByValue("INR");
		Thread.sleep(4000);
		driver.findElementByXPath("(//div[@class='calculator-toggler ']//button)[1]").click();
		Thread.sleep(4000);
		driver.findElementByXPath("(//div[@class='column large-6 calculator-actions']/button)[1]").click();
        Thread.sleep(4000);
        File file2=new File("C:\\Users\\hp\\Downloads");
		File[] fl2=file2.listFiles();
		for(File numberoffile1:fl2) {
			if(numberoffile1.getName().equalsIgnoreCase("ExportedEstimate(1).xlsx")) {
				System.out.println("yes directory has the copy of file with the above name");
				break;
			}
		}
		driver.close();
	}

}
