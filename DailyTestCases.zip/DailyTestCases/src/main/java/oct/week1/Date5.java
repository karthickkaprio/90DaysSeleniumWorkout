package oct.week1;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date5 {

	public static void main(String[] args) throws InterruptedException, IOException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.pepperfry.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.findElementByXPath("//div[@id='regPopUp']/a").click();
	    WebElement frm=driver.findElementById("webklipper-publisher-widget-container-notification-frame");
		driver.switchTo().frame(frm);
		driver.findElementByXPath("//div[@class='close']").click();
		driver.switchTo().defaultContent();
		WebElement furniture=driver.findElementByXPath("(//div[@class='menu_wrapper transition pf-navbar lazy-load']//li)[1]");
		furniture.click();
		driver.findElementByXPath("(//div[@class='hvr-col-list'])[3]/div[12]").click();
        driver.findElementByXPath("(//div[@class='cat-wrap-ttl']/h5)[2]").click();
        WebElement size=driver.findElementByXPath("(//div[@class='clip__filter-dimension-input-holder']/input)[1]");
        size.clear();
        size.sendKeys("50",Keys.ENTER);
        Thread.sleep(1000);
        WebElement frm2=driver.findElementById("webklipper-publisher-widget-container-notification-frame");
		driver.switchTo().frame(frm2);
		driver.findElementByXPath("//div[@class='close']").click();
		driver.switchTo().defaultContent();
        driver.findElementByXPath("(//div[@class='clip-prd-hrt pf-col xs-2'] /a)[5]").click();
        WebElement beddroom=driver.findElementByXPath("(//div[@class='menu_wrapper transition pf-navbar lazy-load']//li)[3]");
		beddroom.click();
		driver.findElementByXPath("(//a[text()='Study Tables'])[3]").click();
		driver.findElementByXPath("//label[@for='brandsnameSpacewood']").click();
		Thread.sleep(2000);
		WebElement checkbox=driver.findElementByXPath("//label[@for='price7000-8000']");
		System.out.println(checkbox.isEnabled());
	    boolean val = checkbox.isSelected();
	    System.out.println(val);
	    /*if(val==false) {
			checkbox.click();*/
			Actions builder =new Actions(driver);
			builder.doubleClick(checkbox).perform();
		
		Thread.sleep(1000);
		driver.findElementByXPath("(//div[@id='productView']//a)[6]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='wishlist_bar']/a").click();
		List<String> mycart=new ArrayList<String>();
		for(int i=0;i<=1;i++) {
		String mywish=driver.findElementsByXPath("//p[@class='item_title pf-bold-txt']/a").get(i).getText();
		mycart.add(mywish);
		}
		if(mycart.get(0).equals("Winner Hutch Table In Rigato Walnut Finish By Spacewood")) {
			System.out.println("yes you are having the rigato table in wishList");
		}else {
			System.out.println("its sold out you dont have rigato table in whishlist please check");
		}
		if(mycart.get(1).equals("Buff High Back Executive Chair In Black Colour By Oblique")) {
			System.out.println("yes you are having the executive chair in wishList");
		}else {
			System.out.println(" its sold out you dont have buff high executive chair in whishlist please check");
		}
		driver.findElementByXPath("(//div[@class='action_block']/a)[1]").click();
		Thread.sleep(1000);
		driver.findElementByXPath("(//div[@class='minicart_footer']/a)[1]").click();
		Thread.sleep(2000);
		driver.findElementById("pin_code").sendKeys("600028");
		driver.findElementByName("pin_check").click();
		driver.findElementByXPath("(//a[text()='PLACE ORDER'])[1]").click();
		Thread.sleep(2000);
		File src=driver.getScreenshotAs(OutputType.FILE);
		File des=new File("./snaps/output.png");
		FileUtils.copyFile(src, des);
		
	}

}
