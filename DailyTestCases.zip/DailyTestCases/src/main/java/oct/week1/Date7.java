package oct.week1;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date7 {

	public static void main(String[] args) throws InterruptedException {
	WebDriverManager.chromedriver().setup();
	ChromeDriver driver =new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	driver.findElementByXPath("//div[@class='nav-search-field ']/input").sendKeys("oneplus7 pro mobile",Keys.ENTER);
	String price=driver.findElementByXPath("(//span[@class='a-price-whole'])[1] ").getText();
	System.out.println("the price of the oneplus7pro mobile is="+" "+price);
	
	driver.findElementByXPath("(//div[@class='a-section a-spacing-none']//img)[1]").click();
	Thread.sleep(3000);
	Set<String> allwindow=driver.getWindowHandles();
	List<String> window=new ArrayList<String>();
	window.addAll(allwindow);
	//String parent=window.get(0);
	String child=window.get(1);
	driver.switchTo().window(child);
	String rating=driver.findElementByXPath("(//a[@id='acrCustomerReviewLink']/span)[1]").getText();
	System.out.println("the number of people who rated is="+" "+rating);
	driver.findElementById("add-to-cart-button").click();
	String confirm=driver.findElementByXPath("//div[@id='huc-v2-order-row-confirm-text']/h1").getText();
	if(confirm.contains("Added to Cart")) {
		System.out.println("i confirm the oneplus7pro mobile is added to the cart");
	}
	else {
		System.out.println("mobile is not added to cart");
	}
	driver.findElementByXPath("//a[@id='hlb-ptc-btn-native']").click();
	Thread.sleep(2000);
	String title=driver.getTitle();
	if(title.contains("Amazon Sign In")) {
		System.out.println("the title is confirmed as Amazon sign in");
	}
	else {
		System.out.println("title not matching check it");
	}
	WebElement proceed=driver.findElementByXPath("//div[@class='a-section']/span");
	Actions builder=new Actions(driver);
	builder.moveToElement(proceed).click(proceed).perform();
	Thread.sleep(2000);
	String error=driver.findElementByXPath("//div[@class='a-alert-content']//span").getText();
	System.out.println(error);
	if(error.contains("Enter your email or mobile phone number")) {
		System.out.println("yes i got the error message");
	}
	else {
		System.out.println("the error message not got as required");
	}
	
	
	
	
	
	

	}

}
