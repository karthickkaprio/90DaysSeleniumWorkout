package oct.week3;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date22 {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.trivago.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//div[@class='dealform__query-wrapper']//input").sendKeys("Agra");
		driver.findElementByXPath("//ul[@id='ssg-suggestions']/li[1]").click();
		Thread.sleep(2000);
		WebDriverWait wait=new WebDriverWait(driver,10);
		WebElement flash=driver.findElementByXPath("//div[@id='onetrust-banner-sdk']//button[2]");
		wait.until(ExpectedConditions.elementToBeClickable(flash));
		flash.click();
		Thread.sleep(4000);
		/*WebElement cal1=driver.findElementByXPath("//button[@data-qa='calendar-checkin']");
		Actions builder=new Actions(driver);
		builder.doubleClick(cal1).perform();
		Thread.sleep(2000);*/
		WebElement tab1=driver.findElementByXPath("//div[@class='two-month-calendar']/table[1]");
		String monthname=driver.findElementByXPath("//table[@class='cal-month']//th/span").getText();
		List<WebElement> row=tab1.findElements(By.tagName("tr"));
		if(monthname.contains("October 2020")) {
			for(int i=0;i<=row.size();i++) {
			if(i==5) {
				driver.findElementByXPath("(//td[@headers='cal-heading-month cal-heading-day5'])[4]").click();
				Thread.sleep(4000);
				}
			
			if(i==6) {
				driver.findElementByXPath("(//td[@headers='cal-heading-month cal-heading-day3'])[5]").click();
				Thread.sleep(4000);
				break;
			}
			System.out.println(i);
			}
		}
		else {
			
			WebElement tab2=driver.findElementByXPath("//div[@class='two-month-calendar']/table[1]");
			driver.findElementByXPath("//div[@class='df_container_calendar']/button[1]").click();
			Thread.sleep(2000);
			String monthname1=driver.findElementByXPath("//table[@class='cal-month']//th/span").getText();
			List<WebElement> row1=tab2.findElements(By.tagName("tr"));
			if(monthname1.contains("October 2020")) {
				for(int i=0;i<=row1.size();i++) {
				if(i==5) {
					driver.findElementByXPath("(//td[@headers='cal-heading-month cal-heading-day5'])[4]").click();
					Thread.sleep(4000);
					}
	
				if(i==6) {
					driver.findElementByXPath("(//td[@headers='cal-heading-month cal-heading-day3'])[5]").click();
					Thread.sleep(4000);
					break;
				}
				System.out.println(i);
				}
			}
			
		}
		driver.findElementByXPath("(//div[@class='room-filters__content']/button)[2]").click();
		driver.findElementByXPath("(//div[@class='room-filters__content']/button)[4]").click();
		WebElement dropdown1=driver.findElementByXPath("//select[@id='child-0']");
		Select sc=new Select(dropdown1);
		sc.selectByVisibleText("4");
		driver.findElementByXPath("(//ul[@class='guest-selector__footer']//button)[2]").click();
		driver.findElementByXPath("//button[@data-qa='search-button']").click();
		Thread.sleep(3000);
		WebElement accom=driver.findElementByXPath("(//ul[@class='toolbar-list']/li/button)[1]");
		Actions builder=new Actions(driver);
		builder.moveToElement(accom).perform();
		driver.findElementByXPath("//li[@class='filter-components__listItem--1fbeb'][2]/input").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='filter-components__starBtnWrapper--beb65']/button[4]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//footer[@class='refinement-row__actions']/button[2]").click();
		WebElement rating=driver.findElementByXPath("(//ul[@class='toolbar-list']/li/button)[2]");
		Actions builder1=new Actions(driver);
		builder1.moveToElement(rating).perform();
		driver.findElementByXPath("//ul[@class='range']/li[2]").click();
		Thread.sleep(2000);
		WebElement location=driver.findElementByXPath("(//ul[@class='toolbar-list']/li/button)[3]");
		Actions builder2=new Actions(driver);
		builder2.moveToElement(location).perform();
		WebElement dropdown2=driver.findElementByXPath("//select[@id='pois']");
		Select sc1=new Select(dropdown2);
		sc1.selectByIndex(1);
		driver.findElementByXPath("//footer[@class='refinement-row__actions']/button[2]").click();
		Thread.sleep(2000);
		WebElement morefilter=driver.findElementByXPath("(//ul[@class='toolbar-list']/li/button)[4]");
		Actions builder3=new Actions(driver);
		builder3.moveToElement(morefilter).perform();
		driver.findElementByXPath("(//li[@data-qa='filters-list-item'])[3]//input").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//li[@data-qa='filters-list-item'])[4]//input").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//li[@data-qa='filters-list-item'])[6]//input").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//footer[@class='refinement-row__actions']/button[2]").click();
		Thread.sleep(2000);
		WebElement dropdown3=driver.findElementByXPath("//select[@id='mf-select-sortby']");
		Select sc2=new Select(dropdown3);
		sc2.selectByIndex(1);
		Thread.sleep(2000);
		String hotelname=driver.findElementByXPath("(//div[@class='item__name item__name--link']//span)[1]").getText();
		System.out.println("Hotel Name="+hotelname);
        String ratingvalue=driver.findElementByXPath("(//div[@class='stars-wrp'])[1]/meta").getAttribute("content");
		System.out.println("Rating value="+ratingvalue);
		String reviews=driver.findElementByXPath("(//button[@data-qa='item-rating-details'])[1]").getText();
		System.out.println("Number of Reviews="+reviews);
		String rev=reviews.replaceAll("\\D", "");
		System.out.println("Number alone="+rev);
		String r=rev.substring(2);
		System.out.println("reviews alone="+r);
		driver.findElementByXPath("(//div[@class='accommodation-list__rowLast--bd14f accommodation-list__row--3de4c']//button)[1]").click();
		Set<String> allwindow=driver.getWindowHandles();
		List<String> win=new ArrayList<String>(allwindow);
		String parent=win.get(0);
		String child=win.get(1);
		driver.switchTo().window(child);
		Thread.sleep(2000);
		String url=driver.getCurrentUrl();
		System.out.println("The current url="+url);
		String price=driver.findElementByXPath("((//div[@class='uitk-grid'])[5]//span)[6]").getText();
		System.out.println("Room Price="+price);
		driver.findElementByXPath("//a[@name='Taj Hotel & Convention Centre, Agra']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//button[@data-stid='submit-hotel-reserve'])[2]").click();
		
		}

}
