package oct.week3;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date19 {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.zalando.com/");
		try{
		WebDriverWait wt=new WebDriverWait(driver,30);
		Alert alert=driver.switchTo().alert();
		wt.until(ExpectedConditions.alertIsPresent());
	    System.out.println(alert.getText());
		alert.accept();
		}catch(Exception e) {
			System.out.println("unhandled alert exception");
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		try{
			WebDriverWait wt=new WebDriverWait(driver,30);
			Alert alert=driver.switchTo().alert();
			wt.until(ExpectedConditions.alertIsPresent());
		    System.out.println(alert.getText());
			alert.accept();
			}catch(Exception e) {
				System.out.println("unhandled alert exception");
			}
		driver.findElementByXPath("//ul[@class='content_nav-wrapper nav']/li[10]").click();
		Thread.sleep(2000);
		//WebDriverWait wait=new WebDriverWait(driver,30);
		WebElement freedelivery=driver.findElementByXPath("//div[@class='z-navicat-header-uspBar_message']//span[2]");
		//wait.until(ExpectedConditions.(freedelivery));
		Actions builder =new Actions(driver);
		builder.moveToElement(freedelivery).perform();
		String free=freedelivery.getText();
		System.out.println(free);
		WebElement cloths=driver.findElementByXPath("(//nav[@class='z-navicat-header_categoryContainer']//span)[2]");
		Actions builder1 =new Actions(driver);
		builder1.moveToElement(cloths).perform();
		driver.findElementByXPath("(//div[@class='JUrPjL']//span)[6]").click();
		//driver.findElementByXPath("(//button[@class='cat_head-3QSpK']//span)[18]").click();
		driver.findElementByXPath("(//button[@aria-label='filter by Material']//span)[3]").click();
		driver.findElementByXPath("(//ul[@class='content cat_list-1KY6Z']//span)[4]").click();
		WebElement save=driver.findElementByXPath("//div[@class='cat_pane-xETbh']//button[2]");
		Actions builder3=new Actions(driver);
		builder3.moveToElement(save).click().perform();
		
		boolean staleElement = true; 

		while(staleElement){

		  try{

			 driver.findElementByXPath("(//span[@id='uc-full-optin-description']//a)[6]").click();

		     staleElement = false;

		  } catch(StaleElementReferenceException e){

		    staleElement = true;

		  }

		} 
		//WebDriverWait wait=new WebDriverWait(driver,60);
		//WebElement notification=driver.findElementByXPath("(//span[@id='uc-full-optin-description']//a)[6]");
		
		//wait.until(ExpectedConditions.elementToBeClickable(notification));
		ChromeOptions chrome=new ChromeOptions();
		chrome.addArguments("--disable.notifications");
		/*Actions builder2 =new Actions(driver);
		builder2.moveToElement(notification).perform();
		builder2.click(notification).perform();
		Thread.sleep(2000);*/
		//JavascriptExecutor executor= (JavascriptExecutor)driver;
		//executor.executeScript("arguments[0].click();", notification);
		
		driver.findElementByXPath("(//button[@class='cat_head-3QSpK']//span)[27]").click();
		driver.findElementByXPath("(//ul[@class='content cat_list-1KY6Z']//span)[3]").click();
	    
		WebElement save1=driver.findElementByXPath("//div[@class='cat_pane-xETbh']//button[2]");
		Actions builder4=new Actions(driver);
		builder4.moveToElement(save1).click().perform();
		//WebDriverWait wait =new WebDriverWait(driver,30);
		WebElement img=driver.findElementByXPath("(//figure[@class='heWLCX']//img)[1]");
		JavascriptExecutor executor= (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", img);
		
		//wait.until(ExpectedConditions.elementToBeClickable(img));
		//img.click();
		
		
		try{
			WebDriverWait wait3=new WebDriverWait(driver,60);
			WebElement notifi=driver.findElementByXPath("//button[@aria-label='Close']");
			wait3.until(ExpectedConditions.elementToBeClickable(notifi));
			notifi.click();
			
		}catch(Exception e) {
			System.out.println("no such element 2");
		}
		
	    String title=driver.findElementByXPath("//div[@class='z-navicat-header_logoWrapper']//img").getAttribute("alt");
	    System.out.println("title is="+title);
	    if(title.contains("Zalando")) {
	    	System.out.println("yes i confirm the title is matching");
	    }
		String brand=driver.findElementByXPath("//div[@class='_1z5_Qg lm1Id5']/a").getText();
		System.out.println("brand is="+brand);
		
		String name=driver.findElementByXPath("(//div[@class='_1z5_Qg lm1Id5']/following::h1)[1]").getText();
		System.out.println("name is="+name);
		
		String colour=driver.findElementByXPath("(//div[@class='hPWzFB']/span)[2]").getText();
		System.out.println("colour is="+colour);
		
		String url=driver.getCurrentUrl();
		System.out.println("url is="+url);
		
		//driver.findElementByXPath("(//button[@type='button']/span)[4]").click();
		driver.findElementByXPath("//button[@id='picker-trigger']").click();
		driver.findElementByXPath("(//div[@data-indicator='border']/label)[2]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//button[@aria-label='Add to bag']/span").click();
		Thread.sleep(3000);
		WebElement bag=driver.findElementByXPath("//a[@title='Your bag']/div");
		Actions builderb=new Actions(driver);
		builderb.moveToElement(bag).perform();
		String brand1=driver.findElementByXPath("(//div[@class='z-coast-fjord-miniCart_articleDetails']//div)[1]").getText();
		System.out.println("brand1="+brand1);
		Thread.sleep(2000);
		String name1=driver.findElementByXPath("(//div[@class='z-coast-fjord-miniCart_articleDetails']//div)[4]").getText();
		System.out.println("name1="+name1);
		Thread.sleep(2000);
		if(brand1.contains(brand)) {
	    	System.out.println("yes i confirm the brand is matching");
	    }
		if(name1.contains(name)) {
	    	System.out.println("yes i confirm the name is matching");
	    }
		
		driver.findElementByXPath("(//div[@class='z-navicat-header-uspBar_message']//a)[2]").click();
		Thread.sleep(8000);
	    driver.findElementByXPath("(//div[@class='channel__button'])[1]").click();
	    Set<String> allwindow=driver.getWindowHandles();
	    List<String> win=new ArrayList<String>(allwindow);
	    String parent=win.get(0);
	    String child=win.get(1);
	    driver.switchTo().window(child);
	    Thread.sleep(4000);
	    driver.findElementByXPath("(//div[@class='value']/input)[1]").sendKeys("karthick");
	    driver.findElementByXPath("(//div[@class='value']/input)[2]").sendKeys("karthick123@gmail.com");
	    driver.findElementByXPath("//button[@id='prechat_submit']/span").click();
	    Thread.sleep(4000);
	    driver.findElementByXPath("//div[@id='liveAgentChatInput']/textarea").sendKeys("hi");
	    driver.findElementByXPath("(//div[@id='bottomelements']//button)[1]").click();
	    Thread.sleep(5000);
	    String replytext=driver.findElementByXPath("(//div[@id='liveAgentChatLogText']//span)[12]").getText();
	    System.out.println("reply text is="+replytext);
	    Thread.sleep(2000);
	    driver.close();
	    driver.switchTo().window(parent);
	    Thread.sleep(2000);
	    driver.close();
		
	}

}
