package oct.week3;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date20 {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.nykaa.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		WebElement brand=driver.findElementByXPath("//ul[@class='HeaderNav']//li[2]");
		Actions builder=new Actions(driver);
		builder.moveToElement(brand).perform();
		WebElement popular=driver.findElementByXPath("(//div[@class='BrandsCategoryHeading']/a)[1]");
		Actions builder1=new Actions(driver);
		builder1.moveToElement(popular).perform();
		driver.findElementByXPath("(//div[@id='brandCont_Popular']//a)[5]").click();
		Set<String> allwindow=driver.getWindowHandles();
		List<String> win=new ArrayList<String>(allwindow);
		String parent=win.get(0);
		String child=win.get(1);
		driver.switchTo().window(child);
		String title=driver.getTitle();
		System.out.println(title);
		if(title.contains("L'Oreal Paris - Buy L'Oreal Paris Products Online at Best Price | Nykaa")) {
			System.out.println("yes i confirm the title is matching");
			}
		ChromeOptions op=new ChromeOptions();
		op.addArguments("--disable.notifications");
		driver.findElementByXPath("//span[@class='pull-right']/i").click();
		driver.findElementByXPath("//div[@for='3']/div").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[text()='Category']").click();
		driver.findElementByXPath("(//label[@for='chk_Shampoo_undefined']/span)[1]").click();
		Thread.sleep(2000);
		String filter=driver.findElementByXPath("//div[@id='sortComponent']//li").getText();
		if(filter.contains("Shampoo")) {
			System.out.println("yes applied filter matches");
		}
		else {
			System.out.println("applied filter not matches");
		}
		driver.findElementByXPath("//div[@class='card-wrapper-container col-xs-12 col-sm-6 col-md-4'][1]").click();
		Set<String> allwindow1=driver.getWindowHandles();
		List<String> win1=new ArrayList<String>(allwindow1);
		String firstchild=win1.get(1);
		String secondchild=win1.get(2);
		driver.switchTo().window(secondchild);
		driver.findElementByXPath("(//button[text()='ADD TO BAG'])[1]").click();
		Thread.sleep(1000);
		String message=driver.findElementByXPath("(//div[@class='mm-text-container']//span)[3]").getText();
		System.out.println("verification message="+message);
		driver.findElementByXPath("//div[@class='AddToBagbox']/div[1]").click();
		//WebDriverWait wait= new WebDriverWait(driver,30);
		WebElement proceed=driver.findElementByXPath("//button[@type='button']/i");
		//wait.until(ExpectedConditions.elementToBeClickable(proceed));
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", proceed);
		Thread.sleep(2000);
		driver.findElementByXPath("//button[@type='submit']/i").click();
		String error=driver.findElementByXPath("(//button[@type='submit']/preceding::span)[6]").getText();
		System.out.println("Error message="+error);
		Thread.sleep(5000);
		driver.close();
		driver.switchTo().window(firstchild);
		Thread.sleep(3000);
		driver.close();
		driver.switchTo().window(parent);
		Thread.sleep(2000);
		driver.close();
	}

}
