package oct.week3;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date21 {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://login.salesforce.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.findElementByXPath("//input[@id='username']").sendKeys("hari.radhakrishnan@testleaf.com");
	    driver.findElementByXPath("//input[@id='password']").sendKeys("India$123");
	    driver.findElementByXPath("//input[@id='Login']").click();
	    ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
	    WebDriverWait wait= new WebDriverWait(driver,30);
	    WebElement togglebutton=driver.findElementByXPath("//div[@class='slds-icon-waffle']");
	    wait.until(ExpectedConditions.elementToBeClickable(togglebutton));
	    togglebutton.click();
	    driver.findElementByXPath("//button[text()='View All']").click();
	    driver.findElementByXPath("//div[@data-name='Service Console']//div[2]").click();
	    Thread.sleep(10000);
	    
	       
	/*try { 
	    WebDriverWait frwait=new WebDriverWait(driver,30);
	    WebElement frm=driver.findElementByXPath("//iframe[@title='dashboard']");
	    frwait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frm));
	    Thread.sleep(2000);
	    //driver.switchTo().frame(frm);
	    driver.findElementByXPath("(//section[@role='dialog']//button)[1]").click();
	    driver.switchTo().defaultContent();
	   
	    }catch(Exception e) {
	    	 System.out.println(e);
	 }*/
	    driver.findElementByXPath("//div[@data-aura-class='oneAppNavMenu']").click();
	    Thread.sleep(2000);
        driver.findElementByXPath("(//ul[@aria-label='Navigation Menu']/li)[7]").click();
	    Thread.sleep(4000);
	   
	    String values=driver.findElementByXPath("(//li[@class='metric']/span)[2]").getText();
	    String closed=values.replaceAll("\\D", "");
	    System.out.println("closed="+closed);
	    Thread.sleep(2000);
	    int close=Integer.parseInt(closed);
	    System.out.println("close="+close);
	    Thread.sleep(2000);
	    ChromeOptions options1=new ChromeOptions();
		options1.addArguments("--disable-notifications");
	    String val=driver.findElementByXPath("(//li[@class='metric']/span)[4]").getText();
	    String opened=val.replaceAll("\\D", "");
	    System.out.println("opened="+opened);
	    Thread.sleep(2000);
	    int open=Integer.parseInt(opened);
	    System.out.println("open="+open);
	    Thread.sleep(2000);
	    int sum=close+open;
	    if(sum<10000) {
	    	driver.findElementByXPath("//button[@data-proxy-id='aura-pos-lib-7']/lightning-primitive-icon").click();
	    	driver.findElementByXPath("//div[@class='goalInputRow']/input").sendKeys("10000");
	    	driver.findElementByXPath("(//div[@class='buttonGroup']/button/span)[2]").click();
	    }
	    else {
	    	System.out.println("the sum of open and close is greater than 10000");
	    }
	    driver.findElementByXPath("//div[@data-aura-class='oneAppNavMenu']").click();
	    Thread.sleep(2000);
	    driver.findElementByXPath("(//ul[@aria-label='Navigation Menu']/li)[5]").click();
	    Thread.sleep(2000);
	   /* driver.findElementByXPath("(//ul[@role='presentation']//a)[1]").click();
	    WebDriverWait frwait1=new WebDriverWait(driver,30);
	    WebElement frm1=driver.findElementByXPath("//iframe[@title='dashboard']");
	    frwait1.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frm1));
	    
	    //driver.switchTo().frame(frm1);
	    driver.findElementByXPath("(//section[@role='dialog']//input)[1]").sendKeys("karthick_workout");
	    driver.findElementByXPath("(//section[@role='dialog']//input)[2]").sendKeys("Testing");
	    driver.findElementByXPath("(//section[@role='dialog']//button)[4]").click();
	    Thread.sleep(5000);
	    driver.findElementByXPath("(//div[@id='main']//button)[9]").click();
	    driver.switchTo().defaultContent();*/
	    WebElement tab1=driver.findElementByXPath("//table[@role='grid']");
	    List<WebElement> row=tab1.findElements(By.tagName("tr"));
	    List<WebElement> data=tab1.findElements(By.tagName("th"));
	    for(int i=0;i<=row.size();i++) {
	    String dashboard=data.get(1).getText();
	    System.out.println("dashboard="+dashboard);
	    if(dashboard.contains("karthick_workout")) {
	    	System.out.println("yes dashboard is created with name karthick");
	    	driver.findElementByXPath("(//td[@role='gridcell'])[5]").click();
	    }
	    else {
	    	System.out.println("no dashboard not created check it");
	    }
	    }
	    
	}

}
