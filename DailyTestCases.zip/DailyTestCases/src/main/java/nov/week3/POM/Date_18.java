package nov.week3.POM;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Date_18 {

	public static void main(String[] args) throws InterruptedException {
	 System.setProperty("webdriver.gecko.driver", "./driver/geckodriver_32 bit.exe");
	 FirefoxDriver driver=new FirefoxDriver();
	 driver.get("https://www.flipkart.com/");
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	 WebElement cross=driver.findElementByXPath("//div[@class='_2QfC02']/button");
     WebDriverWait wait =new WebDriverWait(driver,10);
     wait.until(ExpectedConditions.elementToBeClickable(cross));
     cross.click();
     String showingresult,showing,show,afterresult,after,aft,color,relevance,price1,pr;
     driver.findElementByXPath("//input[@name='q']").sendKeys("home theaters",Keys.ENTER);
     showingresult=driver.findElementByXPath("//span[@class='_10Ermr']").getText();
     showing=showingresult.replaceAll("\\D", "");
     show=showing.substring(3);
     int sh=Integer.parseInt(show);
     driver.findElementByXPath("(//div[@class='_24_Dny'])[1]").click();
     Thread.sleep(3000);
     afterresult=driver.findElementByXPath("//span[@class='_10Ermr']").getText();
     after=afterresult.replaceAll("\\D", "");
     aft=after.substring(3);
     int af=Integer.parseInt(aft);
     if(af<sh) {
    	 System.out.println("yes the showing result reduced after rating button clicked");
    	 }
     Thread.sleep(2000);
     driver.findElementByXPath("(//div[@class='_5THWM1']/div)[4]").click();
     Thread.sleep(2000);
     WebDriverWait wait1=new WebDriverWait(driver,20);
     WebElement colour=driver.findElementByXPath("//div[text()='Price -- High to Low']");
     wait1.until(ExpectedConditions.visibilityOf(colour));
     color=colour.getCssValue("background-color");
	 if(color.contains("rgba(0, 0, 0,255)")) {
		 System.out.println("the background is blue in colour");
	 }
	 else {
		 System.out.println("the background is black in color");
	 }
	 relevance=driver.findElementByXPath("(//div[@class='_5THWM1']/div)[1]").getCssValue("background-color");
	 if(relevance.contains("rgba(0, 0, 0, 0)")){
		System.out.println("yes confirmed all the displayed products are sorted by price");
	 }
	 List<Long> li=new LinkedList<Long>();
	 int count=1;
	 int sum=1;
	 int min=2;
	 for(int i=1;i<=40;i++) {
	 try {
	 WebElement item=driver.findElementByXPath("(//div[@class='_4ddWXP'])["+i+"]");
	 WebDriverWait wait2=new WebDriverWait(driver,10);
	 wait2.until(ExpectedConditions.elementToBeClickable(item));
	 Actions builder1=new Actions(driver);
	 builder1.moveToElement(item).perform();
	 WebElement price=driver.findElementByXPath("(//div[@class='_30jeq3'])["+i+"]");
	 price1=price.getText();
	 pr=price1.replaceAll("\\D", "");
	 long rupee=Long.parseLong(pr);
	 Thread.sleep(500);
	 li.add(rupee);
	 }catch(Exception e) {
		 System.out.println("item move bound exception");
	 }
	if(i==40) {
		 driver.findElementByXPath("//span[text()='Next']").click();
		 i=1;
		 count=count+1;
		 sum=1;
	 }
	 if((i==4)||(i==8)||(i==12)||(i==16)||(i==20)||(i==24)||(i==28)||(i==32)||(i==36)){
		 sum=sum+1;
		 System.out.println("after sum="+sum);
		 try{
			 WebElement row=driver.findElementByXPath("(//div[@class='_13oc-S'])["+sum+"]");
		     Actions builder=new Actions(driver);
		     builder.moveToElement(row).perform();
		 }catch(Exception e) {
			 System.out.println("row move bound exception");
		 }
		 }
	 if(count==7) {
		 while(min==2){
			 WebElement three=driver.findElementByXPath("(//label[@class='_6Up2sF']/span)[3]");
			 JavascriptExecutor exe=(JavascriptExecutor)driver;
			 exe.executeScript("arguments[0].click();", three);
			 Thread.sleep(2000);
			 WebElement four=driver.findElementByXPath("(//label[@class='_6Up2sF']/span)[4]");
		     JavascriptExecutor exe1=(JavascriptExecutor)driver;
			 exe1.executeScript("arguments[0].click();", four);
			 min=min-1;
		} 
	}
	 if(count==8) {
		 break;
		}
	}
	Collections.sort(li);
	Iterator<Long> it=li.iterator();
	while (it.hasNext()) {
		System.out.println(it.next());
		}
	//String expecteditem1="Zoook Boombox plus 32 W Portable Bluetooth Party Speaker";
	//String expecteditem2="JVC XS-XN21 28 W Bluetooth Home Theatre";
	WebElement compare=driver.findElementByXPath("//span[@class='_3hShhO']/span");
    Actions builder3=new Actions(driver);
    builder3.moveToElement(compare).perform();
    Thread.sleep(2000);
    String actualitem1=driver.findElementByXPath("(//div[@class='_3rqrt1'])[1]").getText();
    System.out.println("item1="+actualitem1);
    Thread.sleep(1000);
    String actualitem2=driver.findElementByXPath("(//div[@class='_3rqrt1'])[2]").getText();
    System.out.println("item2="+actualitem2);
   
    /*Assert.assertEquals(actualitem1, expecteditem1);
    System.out.println("yes compare screen contains="+actualitem1);
    Assert.assertEquals(actualitem2, expecteditem2);
    System.out.println("yes compare screen contains="+actualitem2);*/
	}
}

