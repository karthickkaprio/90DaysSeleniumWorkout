package nov.week3.POM;

import java.time.LocalDate;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Date_16 {

	public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Downloads\\driver\\chromedriver.exe");
	ChromeDriver driver=new ChromeDriver();
	driver.get("https://www.zoomcar.com/bangalore/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElementByXPath("//span[@id='select-city']").click();
	Thread.sleep(2000);
	driver.findElementByXPath("//div[text()='Chennai']").click();
    driver.findElementByXPath("//a[@class='search']").click();
    driver.findElementByXPath("(//div[@class='component-popular-locations']/div)[4]").click();
    driver.findElementByXPath("//div[@class='actions']/button").click();
    String date2,convdate,appdate,appdate1,name,carprice,price;
    LocalDate date= LocalDate.now();
    System.out.println("date="+date);
    LocalDate date1=date.plusDays(1);
    //System.out.println("date1="+date1);
    date2=date1.toString();
    convdate=date2.substring(8);
    //System.out.println("convdate="+convdate);
    for(int i=1;i<=7;i++) {
    appdate=driver.findElementByXPath("(//div[@class='days']/div)["+i+"]").getText();
    appdate1=appdate.replaceAll("\\D", "");
    if(appdate1.equalsIgnoreCase(convdate)) {
    	System.out.println("yes matches");
    	driver.findElementByXPath("(//div[@class='days']/div)["+i+"]").click();
    	break;
    }
    Thread.sleep(1000);
    }
    driver.findElementByXPath("//div[@class='actions']/button").click();
    Thread.sleep(2000);
    driver.findElementByXPath("//div[@class='actions']/button").click();
    Thread.sleep(2000);
    TreeMap<Integer,String> tm=new TreeMap<Integer,String>();
    for(int i=1;i<=11;i++) {
    WebElement carname=driver.findElementByXPath("(//div[@class='details']/h3)["+i+"]");
    Actions builder=new Actions(driver);
    builder.moveToElement(carname).perform();
    name=carname.getText();
    carprice=driver.findElementByXPath("(//div[@class='price'])["+i+"]").getText();
    price=carprice.replaceAll("\\D", "");
    int pr=Integer.parseInt(price);
    tm.put(pr, name);
    }
    
    for (Map.Entry map:tm.entrySet()) {
		System.out.println(map.getKey()+" "+map.getValue());
		}
    int high=tm.lastKey();
    System.out.println("highkey="+high);
    if(high==1682) {
    	driver.findElementByXPath("(//div[@class='car-book']//button)[7]").click();
    }
    driver.close();
	}
}
