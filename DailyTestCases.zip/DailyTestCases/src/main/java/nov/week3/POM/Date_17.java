package nov.week3.POM;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_17 {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://paytmmall.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//div[@class='_3XTB']/div[1]").click();
		Thread.sleep(2000);
		WebElement tvandAppli=driver.findElementByXPath("//a[text()='TVs & Appliances']");
        Actions builder=new Actions(driver);
        builder.moveToElement(tvandAppli).perform();
        driver.findElementByXPath("//a[text()='Air Purifiers']").click();
        Thread.sleep(2000);
        WebElement minprice=driver.findElementByXPath("(//div[@class='UTNg']//input)[1]");
        minprice.clear();
        minprice.sendKeys("5000");
        WebElement maxprice=driver.findElementByXPath("(//div[@class='UTNg']//input)[2]");
        maxprice.clear();
        maxprice.sendKeys("15000");
        WebElement sort=driver.findElementByXPath("(//div[@class='_2sw-']//div)[2]");
        Actions builder1=new Actions(driver);
        builder1.moveToElement(sort).perform();
        driver.findElementByXPath("(//div[@class='_2sw-']//div)[5]").click();
        Thread.sleep(2000);
        driver.findElementByXPath("(//div[@class='UGUy'])[1]").click();
        Set<String> allwin=driver.getWindowHandles();
        List<String> win=new ArrayList<String>(allwin);
        String parent=win.get(0);
        String child=win.get(1);
        driver.switchTo().window(child);
        driver.findElementByXPath("//span[text()='Select EMI']").click();
        Thread.sleep(2000);
        WebElement frm=driver.findElementByXPath("//div[@class='_10nQ']/iframe");
        driver.switchTo().frame(frm);
        TreeMap<String,Float> tm=new TreeMap<String,Float>();
        List<String> emi1=new ArrayList<String>();
        for(int i=1;i<=6;i++) {
        WebElement bank=driver.findElementByXPath("(//div[@class='_2Zwf']/div)["+i+"]");
        Actions builder2=new Actions(driver);
        builder2.moveToElement(bank).perform();
        WebDriverWait wait=new WebDriverWait(driver,10);
        wait.until(ExpectedConditions.elementToBeClickable(bank));
        bank.click();
        Thread.sleep(2000);
        String totint=driver.findElementByXPath("(//div[@class='_3Dz1'])[6]").getText();
        String emi=driver.findElementByXPath("(//div[@class='_3Dz1 _1Z3T'])[3]").getText();
        String editemi=emi.substring(0, 6);
        float EMI=Float.parseFloat(editemi);
        System.out.println("bank"+i+" "+"totint="+totint+'\t'+"EMI="+EMI);
        tm.putIfAbsent(totint, EMI);
        bank.click();
       }
        for (Map.Entry st: tm.entrySet()) {
			System.out.println(st.getKey()+" "+st.getValue());
		    Object val=st.getValue();
		    String val1=val.toString();
		    emi1.add(val1);
		}
       String val2=emi1.get(0);
       float val3=Float.parseFloat(val2);
       float val4=(val3*9-5999);
       System.out.println("before rounding val4="+val4);
       int val5=Math.round(val4);
       System.out.println("after rounding val5="+val5);
       if(val5==330) {
    	   System.out.println("yes total amount is verified");
    	   Thread.sleep(2000);
    	   WebElement bank=driver.findElementByXPath("(//div[@class='_2Zwf']/div)[6]");
    	   Actions builder2=new Actions(driver);
    	   builder2.moveToElement(bank).perform();
    	   WebDriverWait wait=new WebDriverWait(driver,10);
    	   wait.until(ExpectedConditions.elementToBeClickable(bank));
    	   bank.click();
    	   Thread.sleep(2000);
    	   driver.findElementByXPath("(//div[@class='_2hgP']//label)[3]").click();
       }
       Thread.sleep(1000);
       driver.findElementByXPath("//div[text()='Proceed with EMI']").click();
       driver.switchTo().defaultContent();
       Thread.sleep(1000);
       driver.findElementByXPath("//span[@class='_3S7f']/i").click();
       Thread.sleep(2000);
       driver.findElementByXPath("(//div[@class='_1IQU']/div)[2]").click();
       String expected="You will get Paytm Cash worth ₹1000";
       String actual=driver.findElementByXPath("//div[@class='fz_t _85Sb']").getText();
       Assert.assertEquals(actual, expected);
       System.out.println("yes offer verified");
       driver.findElementByXPath("//div[@class='_21Qy']/button").click();
       Thread.sleep(2000);
       driver.findElementByXPath("//a[text()='X']").click();
       driver.close();
       Thread.sleep(2000);
       driver.switchTo().window(parent);
       Thread.sleep(2000);
       driver.close();
	}
}
