package nov.week3.POM;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_19 {

	public static void main(String[] args) throws InterruptedException {
	 ChromeOptions option=new ChromeOptions();
	 option.addArguments("--disable-notifications");
     WebDriverManager.chromedriver().setup();
     ChromeDriver driver=new ChromeDriver(option);
     driver.get("https://www.ajio.com/");
     driver.manage().window().maximize();
     driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
     WebElement women=driver.findElementByXPath("//a[text()='WOMEN']");
     WebDriverWait wait=new WebDriverWait(driver,10);
     wait.until(ExpectedConditions.elementToBeClickable(women));
     Actions builder=new Actions(driver);
     builder.moveToElement(women).perform();
     Thread.sleep(2000);
     WebElement brands=driver.findElementByXPath("(//a[text()='BRANDS'])[2]");
     Actions builder1=new Actions(driver);
     builder1.moveToElement(brands).perform();
     
     List<String> li=new ArrayList<String>();
     TreeMap<Integer,String> map=new TreeMap<Integer,String>();
     for(int i=45;i<=56;i++) {
     List<WebElement> counts=driver.findElementsByXPath("(//div[@class='items'])["+i+"]//a");
     for(int j=1;j<=counts.size();j++) {
     String links=driver.findElementByXPath("((//div[@class='items'])["+i+"]//a)["+j+"]").getText();
     li.add(links);
     }
    }
     System.out.println("*********");
     for(String list:li) {
    	 int len=list.length();
    	 map.put(len, list);
    	// System.out.println("b="+list+'\t'+"length="+len);
    	 }
     for(Map.Entry fin:map.entrySet()) {
    	 System.out.println(fin.getKey()+" "+fin.getValue());
    	 }
     String highestchar=map.get(23);
     System.out.println("highestchar="+highestchar);
     Thread.sleep(2000);
     driver.findElementByXPath("//a[text()='"+highestchar+"']").click();
     Thread.sleep(3000);
     String beforeitems=driver.findElementByXPath("(//ul[@class='rilrtl-list ']//label)[1]").getText();
	 System.out.println("items="+beforeitems);
	 String beforeitem=beforeitems.replaceAll("\\D", "");
	 int val1=Integer.parseInt(beforeitem);
	 System.out.println("val1="+val1);
	 driver.findElementByXPath("(//li[@class='rilrtl-list-item']/div)[14]").click();
	 Thread.sleep(2000);
	 driver.findElementByXPath("//label[@for='S']").click();
	 Thread.sleep(3000);
	 String afteritems=driver.findElementByXPath("(//ul[@class='rilrtl-list ']//label)[1]").getText();
	 System.out.println("afteritems="+afteritems);
	 String afteritem=afteritems.replaceAll("\\D", "");
	 int val2=Integer.parseInt(afteritem);
	 System.out.println("val2="+val2);
	 if(val2<val1) {
		 System.out.println("yes no of items reduced after the size checkbox clicked");
	 }
	 WebElement sortby=driver.findElementByXPath("//div[@class='filter-dropdown']/select");
	 Select st1=new Select(sortby);
	 st1.selectByVisibleText("Discount");
	 Thread.sleep(2000);
	 int a[]=new int[12];
	 for(int i=1;i<=10;i++) {
	 String discount=driver.findElementByXPath("(//div[@class='offer-price']/span[2])["+i+"]").getText();
	 String dis=discount.replaceAll("\\D", "");
	 int condis=Integer.parseInt(dis);
	 a[i]=condis;
	}
	 for(int i=1;i<=a.length-1;i++) {
	 System.out.println(a[i]);
	 for(int j=2;j<a.length-1;j++) {
		if((a[j]<a[i])||(a[j]==a[i])) {
			System.out.println("yes result are sorted by higher discount");
			}
	}
	}
	 
}
}
