package nov.week1.testNG;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_2 {
    @Test
	public void runAmazon() throws InterruptedException {
	
	WebDriverManager.chromedriver().setup();
	ChromeDriver driver =new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElementByXPath("//input[@id='twotabsearchtextbox']").sendKeys("oneplus mobile phones",Keys.ENTER);
	String price=driver.findElementByXPath("(//span[@class='a-price'])[2]").getText();
	System.out.println("price of first resulting mobile="+price);
	Thread.sleep(2000);
	driver.findElementByXPath("(//div[@class='a-section a-spacing-none']/h2)[3]").click();
	Set<String> allwin=driver.getWindowHandles();
	List<String> win=new ArrayList<String>(allwin);
	String Grandparentwindow=win.get(0);
	System.out.println("Grandparentwindow="+Grandparentwindow);
	String parentwindow=win.get(1);
	System.out.println("parentwindow="+parentwindow);
    driver.switchTo().window(parentwindow);
    String ratings=driver.findElementByXPath("(//div[@id='averageCustomerReviews_feature_div']//span)[8]").getText();
    System.out.println("customer rating="+ratings);
    WebElement addtocart=driver.findElementByXPath("//span[@id='submit.add-to-cart']//input");
    WebDriverWait wait=new WebDriverWait(driver,30);
    wait.until(ExpectedConditions.elementToBeClickable(addtocart));
    addtocart.click();
    WebElement search =driver.findElementByXPath("//input[@id='twotabsearchtextbox']");
    search.clear();
    search.sendKeys("samsung tv 55 inches",Keys.ENTER);
    Thread.sleep(5000);
    
    WebElement tv=driver.findElementByXPath("(//div[@class='a-section a-spacing-none']//h2//span)[3]");
    WebDriverWait wait1 =new WebDriverWait(driver,30);
    wait1.until(ExpectedConditions.elementToBeClickable(tv));
    tv.click();
    
    Set<String> allwindow=driver.getWindowHandles();
    List<String> window=new ArrayList<String>(allwindow);
    String child1=window.get(2);
    
    //System.out.println("child2="+child1);
    driver.switchTo().window(child1);
    //System.out.println(driver.getTitle());
    String tvprice=driver.findElementByXPath("(//span[@class='a-color-price'])[3]").getText();
    System.out.println("fist available tv with price="+tvprice);
    String tvRatings=driver.findElementByXPath("(//div[@id='averageCustomerReviews']//span)[8]").getText();
    System.out.println("Customer Ratings for tv="+tvRatings);
    driver.findElementByXPath("//span[@id='submit.add-to-cart']//input").click();
    
    String text=driver.findElementByXPath("//div[@id='huc-v2-order-row-confirm-text']/h1").getText();
    System.out.println("Tv is ="+text);
    driver.findElementByXPath("//div[@id='nav-cart-count-container']").click();
    String subtotal=driver.findElementByXPath("(//div[@data-name='Subtotals']//span)[7]").getText();
    System.out.println("subtotal="+subtotal);
    driver.findElementByXPath("//span[@id='sc-buy-box-ptc-button']//input").click();
    Thread.sleep(5000);
    String expected="Amazon Sign In";
    String actual=driver.getTitle();
    Assert.assertEquals(actual, expected);
    System.out.println("title is confirmed");
    driver.findElementByXPath("//span[@id='continue']//input").click();
    String erroractual=driver.findElementByXPath("(//div[@id='auth-email-missing-alert']//div)[2]").getText();
    String errorexpected="Enter your email or mobile phone number";
    Assert.assertEquals(erroractual, errorexpected);
    System.out.println("error message verified");
    Thread.sleep(5000);
    driver.close();
    driver.switchTo().window(parentwindow);
    Thread.sleep(2000);
    driver.close();
    driver.switchTo().window(Grandparentwindow);
    driver.close();
    /*Set<String> allwindow1=driver.getWindowHandles();
    List<String> window1=new ArrayList<String>(allwindow1);
    String child2=window1.get(3);
    driver.switchTo().window(child2)*/;
	}

}
