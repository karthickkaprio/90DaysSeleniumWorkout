package nov.week1.testNG;



	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;
	import java.util.Set;
	import java.util.concurrent.TimeUnit;

	import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.chrome.ChromeOptions;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.Test;
	
	public class Date_3 {
	
	    @Test
		public void runAjio() throws InterruptedException, InvalidFormatException, IOException {
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\hp\\\\Downloads\\\\driver\\\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.ajio.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement men=driver.findElementByXPath("//ul[@class='level-first false']/li[1]");
		Actions builder1=new Actions(driver);
		builder1.moveToElement(men).perform();
		driver.findElementByXPath("(//div[@id='inner']//span/a)[1]").click();
		driver.findElementByXPath("//label[@for='Men - Jackets & Coats']").click();
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		Thread.sleep(2000);
		driver.findElementByXPath("//span[text()='brands']").click();
		driver.findElementByXPath("//div[@class='facet-body']/div").click();
		driver.findElementByXPath("(//label[@for='modal-Campus Sutra'])[1]").click();
		driver.findElementByXPath("(//label[@for='modal-Fort Collins'])[1]").click();
		driver.findElementByXPath("(//label[@for='modal-ARMANI EXCHANGE'])[1]").click();
		driver.findElementByXPath("//button[text()='Apply']").click();
		WebElement colour=driver.findElementByXPath("//span[text()='colors']");
		
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", colour);
	    Thread.sleep(3000);
		driver.findElementByXPath("//label[@for='Black']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//label[@for='Brown']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//span[text()='sleeve']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//label[@for='Full-length']").click();
		Thread.sleep(2000);
		File file=new File("./ExcelWrite/Ajio.xlsx");
		FileInputStream fis=new FileInputStream(file);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheet("sheet1");
		
		ArrayList<Long> amount=new ArrayList<Long>();
		for(int i=1;i<=72;i++) {
		WebElement bd=driver.findElementByXPath("(//div[@class='contentHolder'])["+i+"]//div[1]");
		WebDriverWait cu=new WebDriverWait(driver,30);
		cu.until(ExpectedConditions.elementToBeClickable(bd));
		Actions builder2=new Actions(driver);
		builder2.moveToElement(bd).perform();
		String brand=bd.getText();
		String name=driver.findElementByXPath("(//div[@class='contentHolder'])["+i+"]//div[2]").getText();
		String pr=driver.findElementByXPath("(//div[@class='contentHolder'])["+i+"]//div[3]/span").getText();
		String ru=pr.replaceAll("\\D", "");
		long price=Long.parseLong(ru);
		amount.add(price);
		sheet.getRow(i).createCell(0).setCellValue(i);
		sheet.getRow(i).createCell(1).setCellValue(brand);
		sheet.getRow(i).createCell(2).setCellValue(name);
		sheet.getRow(i).createCell(3).setCellValue(price);
		System.out.println("S.No="+i+'\t'+"Brand="+brand+'\t'+"Name="+name+'\t'+"price="+pr);
		}
		FileOutputStream fos=new FileOutputStream(file);
		wb.write(fos);
		wb.close();
		Collections.sort(amount);
		/*for(long rupee:amount) {
			System.out.println(rupee);
		}*/
		System.out.println("Lowest Price of jacket="+amount.get(0));
		System.out.println("Highest price of jacket="+amount.get(71));
		WebElement sortby=driver.findElementByXPath("//div[@class='sort ']//select");
		Actions builde=new Actions(driver);
		builde.moveToElement(sortby).perform();
		Select sy=new Select(sortby);
		sy.selectByValue("prce-desc");
		Thread.sleep(5000);
		WebElement firstimage=driver.findElementByXPath("//div[@class='preview']//img");
		WebDriverWait wt=new WebDriverWait(driver,30);
		wt.until(ExpectedConditions.elementToBeClickable(firstimage));
		firstimage.click();
		Set<String> allwin=driver.getWindowHandles();
		List<String> win=new ArrayList<String>(allwin);
		String parent=win.get(0);
		String child=win.get(1);
		driver.switchTo().window(child);
		driver.findElementByXPath("(//div[@class='size-swatch']/div)[2]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='btn-gold']").click();
		
		WebElement men1=driver.findElementByXPath("(//div[@class='menu-newlist']//li)[1]");
		WebDriverWait wait=new WebDriverWait(driver,60);
	    wait.until(ExpectedConditions.elementToBeClickable(men1));
		Actions builder3=new Actions(driver);
		builder3.moveToElement(men1).perform();
		driver.findElementByXPath("//a[text()='Sneakers']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//label[@for='Men']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//label[@for='Men - Sneakers & Sports Shoes']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//span[text()='brands']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='facet-body']/div").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//label[@for='modal-Men - Casual Shoes']").click();
		/*driver.findElementByXPath("//label[@for='modal-ASICS']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//label[@for='modal-ARMANI EXCHANGE']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//button[@type='button']/div)[11]").click();
		WebElement check1=driver.findElementByXPath("//label[@for='modal-EA7 Emporio Armani']");
		Actions builder4=new Actions(driver);
		builder4.moveToElement(check1).perform();
		check1.click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//button[@type='button']/div)[15]").click();
		WebElement check2=driver.findElementByXPath("//label[@for='modal-G STAR RAW']");
		Actions builder5=new Actions(driver);
		builder5.moveToElement(check2).perform();
		check2.click();
		Thread.sleep(2000);
	    WebElement check3=driver.findElementByXPath("//label[@for='modal-GAS']");
	    Actions builder6=new Actions(driver);
		builder6.moveToElement(check3).perform();
		check3.click();*/
		Thread.sleep(2000);
		driver.findElementByXPath("//button[text()='Apply']").click();
		Thread.sleep(5000);
		driver.findElementByXPath("//div[@class='preview']//img").click();
		Set<String> allwindow=driver.getWindowHandles();
		List<String> window=new ArrayList<String>(allwindow);
		String child2=window.get(2);
		driver.switchTo().window(child2);
		String sheo=driver.findElementByXPath("//div[@class='prod-content']//h1").getText();
		String sheoprice=driver.findElementByXPath("//div[@class='prod-price-section ']/div[1]").getText();
		System.out.println("Sheo name="+sheo+'\t'+"price="+sheoprice);
		driver.findElementByXPath("(//div[@data-index='1'])[3]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='btn-gold']").click();
		WebElement proceed=driver.findElementByXPath("//div[text()='PROCEED TO BAG']");
		WebDriverWait w=new WebDriverWait(driver,30);
		w.until(ExpectedConditions.elementToBeClickable(proceed));
		proceed.click();
		Thread.sleep(2000);
	    System.out.println("order summary");
	    for(int i=1;i<=5;i++) {
		String leftpart=driver.findElementByXPath("(//section[@class='price-summary'])["+i+"]/span[1]").getText();
		String rightpart=driver.findElementByXPath("(//section[@class='price-summary'])["+i+"]/span[2]").getText();
		System.out.println(leftpart+'\t'+rightpart);
		
		}
		driver.findElementByXPath("//button[text()='Proceed to shipping']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//input[@class='login-btn']").click();
		String text=driver.findElementByXPath("//div[@id='error-msg']").getText();
		System.out.println("Display message="+text);
		Thread.sleep(5000);
		//driver.close();
		driver.switchTo().window(child);
		Thread.sleep(2000);
		driver.close();
		driver.switchTo().window(parent);
		Thread.sleep(2000);
		driver.close();
	    }

	}


