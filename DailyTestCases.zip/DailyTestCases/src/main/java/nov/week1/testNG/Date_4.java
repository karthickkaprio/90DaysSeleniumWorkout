package nov.week1.testNG;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_4 {

	public static void main(String[] args) throws InterruptedException, IOException {
	WebDriverManager.chromedriver().setup();
	ChromeDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.get("https://www.carwale.com/");
    driver.findElementByXPath("//div[@data-index='1']/parent::div").click();
    driver.findElementByXPath("(//input[@type='text'])[2]").sendKeys("Chennai");
    driver.findElementByXPath("//li[@label='Chennai, Tamil Nadu']/div").click();
    driver.findElementByXPath("//input[@placeholder='Min']").sendKeys("8");
    driver.findElementByXPath("//input[@placeholder='Max']").sendKeys("12");
    driver.findElementByXPath("//button[text()='Search']").click();
    driver.findElementByXPath("(//li[@name='CarsWithPhotos']/span)[1]").click();
    Thread.sleep(3000);
    ChromeOptions option=new ChromeOptions();
    option.addArguments("--disable-notifications");
    WebElement hyundai=driver.findElementByXPath("//span[text()=' Hyundai ']");
    JavascriptExecutor exe=(JavascriptExecutor)driver;
    exe.executeScript("arguments[0].click();", hyundai);
    Thread.sleep(2000);
    WebElement creta= driver.findElementByXPath("(//ul[@class='rootUl']/li/span)[1]");
    JavascriptExecutor exe1=(JavascriptExecutor)driver;
    exe1.executeScript("arguments[0].click();", creta);
    Thread.sleep(2000);
    WebElement fuel=driver.findElementByXPath("//div[@name='fuel']");
    JavascriptExecutor exe3=(JavascriptExecutor)driver;
    exe3.executeScript("arguments[0].click();", fuel);
    Thread.sleep(2000);
    WebElement petrol=driver.findElementByXPath("//span[text()='Petrol']");
    JavascriptExecutor exe4=(JavascriptExecutor)driver;
    exe4.executeScript("arguments[0].click();", petrol);
    Thread.sleep(2000);
    WebElement bestmatch=driver.findElementByXPath("//select[@id='sort']");
    Select bm=new Select(bestmatch);
    bm.selectByValue("2");
    Thread.sleep(2000);
    driver.findElementByXPath("//p[@class='margin-top5']/a").click();
    Thread.sleep(2000);
    System.out.println("details for validating car 1");
    WebElement tbKM1=driver.findElementByXPath("(//div[@class='card-detail-block']//table)[2]");
    List<WebElement> km1=tbKM1.findElements(By.tagName("td"));
    String a[]=new String[km1.size()];
    for(int i=0;i<=a.length-1;i++) {
    	a[i]=km1.get(i).getText();
    	System.out.println("val("+i+")="+'\t'+a[i]);
    }
    System.out.println("details for validating car 2");
    WebElement tbKM2=driver.findElementByXPath("(//div[@class='card-detail-block']//table)[4]");
    List<WebElement> km2=tbKM2.findElements(By.tagName("td"));
    String b[]=new String[km2.size()];
    for(int i=0;i<=b.length-1;i++) {
    	b[i]=km2.get(i).getText();
    	System.out.println("val("+i+")="+'\t'+b[i]);
    }
    String val1="";
    for(int j=0;j<=a.length-1;j++) {
    	val1=a[0].toString();
    }
    String val2="";
    for(int k=0;k<=b.length-1;k++) {
    	val2=b[0].toString();
    }
    String con1=val1.replaceAll("\\D", "");
    long firstcar =Long.parseLong(con1);
    String con2=val2.replaceAll("\\D", "");
    long secondcar =Long.parseLong(con2);
    
    if(firstcar==secondcar) {
    	System.out.println("both the cars ran same km");
    }
    else if(firstcar<secondcar) {
    	System.out.println("first car ran lower km");
    	driver.findElementByXPath("(//ul[@id='listing1']//span)[4]").click();
    	
    }
    else if(firstcar>secondcar) {
    	System.out.println("second car ran lower km");
    	driver.findElementByXPath("(//ul[@id='listing1']//span)[22]").click();
    	
    }
    Thread.sleep(2000);
    driver.findElementByXPath("//li[@data-role='click-tracking']").click();
    Thread.sleep(2000);
    driver.findElementByXPath("//a[text()='More details �']").click();
    Set<String> allwin=driver.getWindowHandles();
    List<String> win=new ArrayList<String>(allwin);
    String parent=win.get(0);
    String child=win.get(1);
    driver.switchTo().window(child);
    File file=new File("./ExcelWrite/carwale.xlsx");
    FileInputStream fis=new FileInputStream(file);
    XSSFWorkbook wb=new XSSFWorkbook(fis);
    XSSFSheet sheet=wb.getSheet("sheet1");
    System.out.println("overview");
    for(int i=1;i<=13;i++) {
    	String firstcolum=driver.findElementByXPath("(//div[@id='overview']//li)["+i+"]/div[1]").getText();
    	String secondcolum=driver.findElementByXPath("(//div[@id='overview']//li)["+i+"]/div[2]").getText();
    	System.out.println(firstcolum+'\t'+secondcolum);
    	sheet.getRow(i).createCell(0).setCellValue(firstcolum);
    	sheet.getRow(i).createCell(1).setCellValue(secondcolum);
    }
    FileOutputStream fos=new FileOutputStream(file);
    wb.write(fos);
    wb.close();
    Thread.sleep(5000);
    driver.close();
    driver.switchTo().window(parent);
    Thread.sleep(2000);
    driver.close();
	}

}
