package nov.week1.testNG;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_5 {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://demo.1crmcloud.com/login.php?login_module=Home&login_action=index");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//input[@id='login_user']").sendKeys("admin");
		driver.findElementByXPath("//input[@id='login_pass']").sendKeys("admin");
		WebElement theme=driver.findElementByName("user_theme");
		Select the=new Select(theme);
		the.selectByValue("Claro");
		driver.findElementByXPath("(//button[@id='login_button']/span)[1]").click();
		/*WebElement sales=driver.findElementByXPath("//li[@id='grouptab-1']/a");
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.elementToBeClickable(sales));
		sales.click();
		driver.findElementByXPath("(//div[@id='sidebar-shortcuts']//div)[4]").click();
		Thread.sleep(5000);
		driver.findElementByXPath("//div[@id='DetailFormsalutation-input']").click();
		Thread.sleep(5000);
		driver.findElementByXPath("//div[text()='Mr.']").click();
		Thread.sleep(5000);
		driver.findElementByXPath("//input[@id='DetailFormfirst_name-input']").sendKeys("karthick");
		driver.findElementByXPath("//input[@id='DetailFormlast_name-input']").sendKeys("N");
		driver.findElementByXPath("//input[@id='DetailFormemail1-input']").sendKeys("karthickkala93@gmail.com");
		driver.findElementByXPath("//input[@id='DetailFormphone_work-input']").sendKeys("5454545454");
		driver.findElementByXPath("//div[@id='DetailFormlead_source-input']").click();
		driver.findElementByXPath("//div[text()='Public Relations']").click();
		driver.findElementByXPath("//div[@id='DetailFormbusiness_role-input']").click();
		driver.findElementByXPath("//div[text()='Sales']").click();
		driver.findElementByXPath("//textarea[@id='DetailFormprimary_address_street-input']").sendKeys("97/B,rahumath nagar,43rd street,palayamkottai");
		driver.findElementByXPath("//input[@id='DetailFormprimary_address_city-input']").sendKeys("Tirunelveli");
		driver.findElementByXPath("//input[@id='DetailFormprimary_address_state-input']").sendKeys("TamilNadu");
		driver.findElementByXPath("//input[@id='DetailFormprimary_address_country-input']").sendKeys("India");
		driver.findElementByXPath("//input[@id='DetailFormprimary_address_postalcode-input']").sendKeys("627353");
		Thread.sleep(3000);
		driver.findElementByXPath("//button[@id='DetailForm_save2']").click();
		Thread.sleep(3000);*/
		WebElement today=driver.findElementByXPath("//li[@id='grouptab-0']/a");
		Actions builder1=new Actions(driver);
		builder1.moveToElement(today).perform();
		driver.findElementByXPath("//div[text()='Meetings']").click();
		try{
		Alert alert=driver.switchTo().alert();
		alert.accept();
		}catch(Exception e) {
			System.out.println(e);
		}
		Thread.sleep(5000);
		driver.findElementByXPath("//button[@name='SubPanel_create']").click();
		Thread.sleep(5000);
		driver.findElementByXPath("//input[@id='DetailFormname-input']").sendKeys("Project status");
		driver.findElementByXPath("//div[@id='DetailFormstatus-input']").click();
		Thread.sleep(2000);
		WebElement planned=driver.findElementByXPath("//div[text()='Planned']");
		Actions builder2=new Actions(driver);
		builder2.doubleClick(planned).perform();
		//planned.click();
		Thread.sleep(3000);
		driver.findElementByXPath("//div[@id='DetailFormdate_start-input']").click();
		Thread.sleep(2000);
		WebElement datetext=driver.findElementByXPath("//div[@id='DetailFormdate_start-calendar-text']//input");
		LocalDate date=LocalDate.now();
		System.out.println("currdt="+date);
		LocalDate date1=date.plusDays(1);
		String date2=date1.toString();
		System.out.println("tomdt="+date1);
		datetext.clear();
		datetext.sendKeys(date2,Keys.ENTER);
		Thread.sleep(2000);
		datetext.clear();
		datetext.sendKeys("03:00",Keys.ENTER);
		Thread.sleep(2000);
		WebElement hour=driver.findElementByXPath("//input[@id='DetailFormduration-time']");
		hour.clear();
		hour.sendKeys("01:00",Keys.ENTER);
		Thread.sleep(2000);
		//driver.findElementByTagName("//button[@name='addInvitee']").click();
		driver.findElementByXPath("(//span[text()='Save'])[2]").click();
		
		
        
	}

}
