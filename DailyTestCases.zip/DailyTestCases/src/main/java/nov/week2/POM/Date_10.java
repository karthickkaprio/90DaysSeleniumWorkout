package nov.week2.POM;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_10 {

	public static void main(String[] args) throws InterruptedException {
	 WebDriverManager.chromedriver().setup();
	 ChromeDriver driver=new ChromeDriver();
	 driver.get("https://www.walmart.com/");
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	/*try {
	 WebDriverWait wait =new WebDriverWait(driver,5);
	 WebElement frm=driver.findElementByXPath("//iframe[@role='presentation']");
	 wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frm));
	 WebElement robot=driver.findElementByXPath("//div[@class='recaptcha-checkbox-border']");
	 Actions builde=new Actions(driver);
	 builde.moveToElement(robot).perform();
	 builde.click();
	 driver.switchTo().defaultContent();
	}catch(Exception e) {
		System.out.println("there is no captcha");
	}*/
	 driver.findElementByXPath("//button[@id='header-Header-sparkButton']").click();
	 WebElement department=driver.findElementByXPath("(//div[@id='vh-department-menu']/button)[5]");
	 Actions builder=new Actions(driver);
	 builder.moveToElement(department).perform();
	 driver.findElementByXPath("(//div[text()='Shoes'])[1]").click();
	 driver.findElementByXPath("(//a[text()='Comfort Shoes'])[3]").click();
	 Thread.sleep(2000);
	 driver.findElementByXPath("//a[text()='Sneakers']").click();
	 Thread.sleep(3000);
	 SortedMap<String,Float> tm=new TreeMap<String,Float>();
	 //int count=1;
	 for(int i=1;i<=43;i++) {	
	 try {
		 WebElement br=driver.findElementByXPath("(//span[@class='product-brand']/strong)["+i+"]");
		 WebDriverWait wait=new WebDriverWait(driver,2);
		 wait.until(ExpectedConditions.elementToBeClickable(br));
		 Actions builder1=new Actions(driver);
		 builder1.moveToElement(br).perform();
		 String brand=br.getText();
	     if(brand.equalsIgnoreCase("The Flexx")||brand.equalsIgnoreCase("Propet")) {
		   String sheo=driver.findElementByXPath("(//div[@class='search-result-product-title gridview']//a)["+i+"]").getAttribute("href");
		   String sheoname=sheo.replaceAll("\\d", "");
		   Thread.sleep(300);
		   String editedsheoname=sheoname.substring(27);
		   String pr=driver.findElementByXPath("(//span[@class='price-main-block'])["+i+"]").getText();
		   String pr1=pr.substring(1, 6);
		   float ru=Float.parseFloat(pr1);
		   Thread.sleep(200);
		   //System.out.println("sheoname="+editedsheoname+'\t'+"price="+ru);
		   tm.put(editedsheoname, ru);
		   }
	     }catch(Exception e) {
	       System.out.println("no price added");
		}
	 }
	 /*if(i==43) {
		 count=count+1;
		 driver.findElementByXPath("//ul[@class='paginator-list']/following::button[1]").click();
		 Thread.sleep(3000);
		 i=1;
	 }
	 break;
	 }*/
	 System.out.println("******************");
	 for(Map.Entry print:tm.entrySet()) {
		 System.out.println(print.getKey()+" "+'\t'+" "+print.getValue());
		 }
	
	}
}
	 


