package nov.week2.POM;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_9 {

public static void main(String[] args) throws InterruptedException {
	ChromeOptions option=new ChromeOptions();
	option.addArguments("--disable-notifications-");
	WebDriverManager.chromedriver().setup();
	ChromeDriver driver=new ChromeDriver(option);
	driver.get("https://www.airbnb.co.in/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElementByXPath("//label[@for='bigsearch-query-detached-query']//input").sendKeys("Baga");
	driver.findElementByXPath("(//ul[@role='listbox']//li)[2]").click();
	
	LocalDate nowdate=LocalDate.now();
	System.out.println("date="+nowdate);
	LocalDate checkin=nowdate.plusDays(10);
	System.out.println("plusdate="+checkin);
	LocalDate checkout=checkin.plusDays(5);
	driver.findElementByXPath("//div[@data-testid='datepicker-day-"+checkin+"']").click();
	Thread.sleep(1000);
	driver.findElementByXPath("//div[@data-testid='datepicker-day-"+checkout+"']").click();
	Thread.sleep(2000);
	WebElement flexible=driver.findElementByXPath("(//div[@class='_1o2zacc']/label)[3]");
	Actions builder=new Actions(driver);
	builder.moveToElement(flexible).perform();
	JavascriptExecutor exe=(JavascriptExecutor)driver;
	exe.executeScript("arguments[0].click();",flexible);
	Thread.sleep(1000);
	driver.findElementByXPath("//div[text()='Add guests']").click();
	Thread.sleep(1000);
	WebElement adult=driver.findElementByXPath("//button[@data-testid='stepper-adults-increase-button']");
    adult.click();
    Thread.sleep(1000);
    adult.click();
    Thread.sleep(1000);
    WebElement children=driver.findElementByXPath("//button[@data-testid='stepper-children-increase-button']");
    children.click();
    Thread.sleep(1000);
    driver.findElementByXPath("//button[@class='_1mzhry13']").click();
    try{
    	WebElement cookie=driver.findElementByXPath("(//div[@data-testid='main-cookies-banner-container']//button)[2]");
    	WebDriverWait wt=new WebDriverWait(driver,20);
    	wt.until(ExpectedConditions.elementToBeClickable(cookie));
    	cookie.click();
    	}catch(Exception e) {
    		System.out.println("no such cookie");
    	}
    WebElement roomtype=driver.findElementByXPath("//div[@id='menuItemButton-room_type']");
    WebDriverWait wait=new WebDriverWait(driver,10);
    wait.until(ExpectedConditions.elementToBeClickable(roomtype));
    roomtype.click();
    WebElement hotel=driver.findElementByXPath("(//div[@data-testid='menuBarPanel-room_type']//label)[3]");
    JavascriptExecutor exe1=(JavascriptExecutor)driver;
    exe1.executeScript("arguments[0].click();", hotel);
    driver.findElementByXPath("//button[@id='filter-panel-save-button']").click();
    Thread.sleep(8000);
    WebElement price=driver.findElementByXPath("//div[@id='menuItemButton-price_range']");
    wait.until(ExpectedConditions.elementToBeClickable(price));
    price.click();
    WebElement minprice=driver.findElementByXPath("(//div[@class='_fywymp7']//input)[1]");
    minprice.sendKeys(Keys.CONTROL, Keys.chord("a")); //select all text in textbox
    minprice.sendKeys(Keys.BACK_SPACE); //delete it
    minprice.sendKeys("1000");
    Thread.sleep(1000);
    driver.findElementByXPath("//button[@id='filter-panel-save-button']").click();
    try{
    price.click();
    WebElement maxprice=driver.findElementByXPath("(//div[@class='_fywymp7'])[2]//input");
    Actions builder5=new Actions(driver);
    builder5.moveToElement(maxprice).perform();
    maxprice.sendKeys(Keys.CONTROL, Keys.chord("a")); //select all text in textbox
    maxprice.sendKeys(Keys.BACK_SPACE); //delete it
    maxprice.sendKeys("10000");
    Thread.sleep(1000);
    driver.findElementByXPath("//button[@id='filter-panel-save-button']").click();
    }catch(Exception e) {
    	System.out.println("no such operation can be performed");
    }
    Thread.sleep(2000);
    WebElement morefilter=driver.findElementByXPath("//div[@id='menuItemButton-dynamicMoreFilters']");
    wait.until(ExpectedConditions.elementToBeClickable(morefilter));
    morefilter.click();
    WebElement bed=driver.findElementByXPath("(//button[@aria-label='increase value'])[1]");
    bed.click();
    Thread.sleep(1000);
    bed.click();
    WebElement bedroom=driver.findElementByXPath("(//button[@aria-label='increase value'])[2]");
    bedroom.click();
    driver.findElementByXPath("//button[@data-testid='more-filters-modal-submit-button']").click();
    WebElement firstitem=driver.findElementByXPath("//div[@class='_1048zci']/a");
    wait.until(ExpectedConditions.elementToBeClickable(firstitem));
    firstitem.click();
    Set<String> allwin=driver.getWindowHandles();
    List<String> win=new ArrayList<String>(allwin);
    String parent=win.get(0);
    String child=win.get(1);
    driver.switchTo().window(child);
    Thread.sleep(2000);
    WebElement pernight=driver.findElementByXPath("(//div[@class='_xqcexm']//span)[2]");
    wait.until(ExpectedConditions.elementToBeClickable(pernight));
    String amount=pernight.getText();
    String amo=amount.replaceAll("\\D", "");
    //System.out.println("amo="+amo);
    int amo1=amo.length();
    int onenight;
    if(amo1>4) {
    	String amo2=amo.substring(4);
    	onenight=Integer.parseInt(amo2);
    	System.out.println("if onenight="+onenight);
    }else {
        onenight=Integer.parseInt(amo);
        System.out.println("else onenight="+onenight);
    }
    int totalamount=onenight*5;
    //System.out.println("totalamount="+totalamount);
    String displayamount=driver.findElementByXPath("(//li[@class='_ryvszj']/span)[2]").getText();
    String display=displayamount.replaceAll("\\D", "");
    int dis=Integer.parseInt(display);
    if(totalamount==dis) {
    	System.out.println("yes the calculate amount and display amount matches");
    }else {
    	System.out.println("calculated amount and display amount not matching");
    }
    String ExpectedCheckin="12/4/2020";
    String Actualcheckin=driver.findElementByXPath("(//div[@class='_1acx77b']/div)[2]").getText();
    Assert.assertEquals(Actualcheckin, ExpectedCheckin);
    System.out.println("yes check in matches");
    String ExpectedCheckout="12/9/2020";
    String Actualcheckout=driver.findElementByXPath("(//div[@class='_14tl4ml5']/div)[2]").getText();
    Assert.assertEquals(Actualcheckout, ExpectedCheckout);
    System.out.println("yes check out matches");
    Thread.sleep(2000);
    driver.close();
    driver.switchTo().window(parent);
    Thread.sleep(2000);
    driver.close();
}

}
