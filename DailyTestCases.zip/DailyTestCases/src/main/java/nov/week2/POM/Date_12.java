package nov.week2.POM;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.formula.functions.T;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_12 {

	public static void main(String[] args) throws InterruptedException {
	ChromeOptions option=new ChromeOptions();
	option.addArguments("--disable-notifications-");
	WebDriverManager.chromedriver().setup();
	ChromeDriver driver=new ChromeDriver(option);
	driver.get("https://www.samsung.com/in/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	WebElement cookie=driver.findElementByXPath("//button[@class='cookie-bar__close cookie-bar__main-close']");
	WebDriverWait wait=new WebDriverWait(driver,20);
	wait.until(ExpectedConditions.elementToBeClickable(cookie));
	cookie.click();
    WebElement offers=driver.findElementByXPath("//a[@data-engname='offers']/span");
    Actions builder=new Actions(driver);
    builder.moveToElement(offers).perform();
    WebElement shopmobile=driver.findElementByXPath("//a[@data-engname='offers:shop mobile']/span");
    builder.moveToElement(shopmobile).perform();
    driver.findElementByXPath("//a[@an-la='offers:shop mobile:shop galaxy m series']/span").click();
    Thread.sleep(2000);
    WebElement button=driver.findElementByXPath("(//button[@class='menu__select-field'])[1]");
    JavascriptExecutor exe=(JavascriptExecutor)driver;
	exe.executeScript("arguments[0].click();", button);
	WebElement afterbutton=driver.findElementByXPath("(//ul[@role='listbox']//button)[2]");
	wait.until(ExpectedConditions.elementToBeClickable(afterbutton));
	afterbutton.click();
	Thread.sleep(2000);
    driver.findElementByXPath("(//a[@data-type='emi'])[1]").click();
	WebElement frm=driver.findElementByXPath("//iframe[@name='Estimate_iframe']");
	WebDriverWait wait2=new WebDriverWait(driver,10);
	wait2.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frm));
	driver.findElementByXPath("(//div[@class='tabset']/label)[1]").click();
	driver.findElementByXPath("//a[text()='SBI']").click();
	TreeMap<Float,Integer> tm=new TreeMap<Float,Integer>();
	WebElement tab1=driver.findElementByXPath("(//div[@class='emi-plans-holder']/table)[1]");
	List<WebElement> row=tab1.findElements(By.tagName("tr"));
	//System.out.println(row.size());
	List<WebElement> column=tab1.findElements(By.tagName("td"));
	//System.out.println(column.size());
	int conint=0;
	float conint1=0;
	String columndata1,columndata2,concolum,concolum1;
	for(int i=1;i<=row.size()-1;i++) {
		for(int j=0;j<=column.size()-1;j++) {
			if((j%2==0)&&(j!=2)&&(j!=6)&&(j!=10)){
			columndata1=column.get(j).getText();
			concolum=columndata1.substring(11,12);
			conint=Integer.parseInt(concolum);
			}
			if((j==2)||(j==6)||(j==10)) {
			columndata2=column.get(j).getText();
			concolum1=columndata2.replaceFirst("\\D", "");
			conint1=Float.parseFloat(concolum1);
			tm.put(conint1, conint);
			}
			}
		}
	
	for(Map.Entry map:tm.entrySet()) {
		System.out.println(map.getKey()+" "+map.getValue());
		}
	Float discounthigh =tm.lastKey();
	System.out.println("discounthigh="+discounthigh);
	int month=tm.get(discounthigh);
	double calculation=month*2333.16;
	System.out.println("calculation="+calculation);
	String totalpayable=driver.findElementByXPath("((//div[@class='emi-plans-holder'])[1]//td)[8]").getText();
    System.out.println("totalpayable="+totalpayable);
	String total=totalpayable.replaceAll("\\D", "");
	System.out.println("total="+total);
    double tot=Double.parseDouble(total);
    System.out.println("tot="+tot);
    if(calculation==tot) {
    	System.out.println("yes emi plan amount is equal to total payable amount");
    }
    String productcost=driver.findElementByXPath("//div[@class='modal-content aem-content']/h3").getText();
	System.out.println("productcost="+productcost);
    String procost=productcost.replaceAll("\\D", "");
    System.out.println("procost="+procost);
	double cost=Double.parseDouble(procost);
	System.out.println("cost="+cost);
	double val=cost-tot;
	System.out.println("val="+val);
	driver.switchTo().defaultContent();
	WebDriverWait wait4=new WebDriverWait(driver,10);
	WebElement cross=driver.findElementByXPath("//div[@id='eip-popup']//button");
	wait4.until(ExpectedConditions.elementToBeClickable(cross));
	cross.click();
	WebElement buynow=driver.findElementByXPath("(//a[text()='Buy now'])[1]");
	wait4.until(ExpectedConditions.elementToBeClickable(buynow));
	buynow.click();
	WebElement addtocart=driver.findElementByXPath("(//a[text()='ADD TO CART'])[2]");
	wait4.until(ExpectedConditions.elementToBeClickable(addtocart));
	addtocart.click();
	WebElement add=driver.findElementByXPath("(//button[text()='Add'])");
	wait4.until(ExpectedConditions.elementToBeClickable(add));
	add.click();
	WebElement radio=driver.findElementByXPath("(//input[@name='_paymentMethodType'])[2]");
	wait4.until(ExpectedConditions.elementToBeClickable(radio));
	JavascriptExecutor exe3=(JavascriptExecutor)driver;
	exe3.executeScript("arguments[0].click();", radio);
	driver.findElementByXPath("(//span[@class='cc-box-checkbox'])[5]").click();
	WebElement addtocart1=driver.findElementByXPath("//button[text()='Add to Cart']");
	Actions builder2=new Actions(driver);
	builder2.moveToElement(addtocart1).perform();
	addtocart1.click();
	String title=driver.findElementByXPath("//div[@class='sc-product-meta-data']/h2").getText();
	System.out.println("product title="+title);
	Thread.sleep(3000);
	String totalamount=driver.findElementByXPath("(//div[@class='os-price-row total-price-row']/p)[2]").getText();
	System.out.println("totalamount="+totalamount);
	}
}

