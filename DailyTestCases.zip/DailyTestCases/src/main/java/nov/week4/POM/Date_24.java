package nov.week4.POM;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_24 {

	public static void main(String[] args) throws InterruptedException, IOException {
	 WebDriverManager.edgedriver().setup();
	 EdgeOptions option=new EdgeOptions();
	 option.setCapability("--disable-notification", true);
	 EdgeDriver driver=new EdgeDriver(option);
	 Capabilities cap1=driver.getCapabilities();
	 String name1=cap1.getBrowserName();
	 String version1=cap1.getVersion();
	 System.out.println("name1="+name1);
     System.out.println("version1="+version1);
     driver.get("https://www.redbus.in/");
     driver.manage().window().maximize();
     driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
     WebElement to=driver.findElementByXPath("//input[@id='dest']");
     to.sendKeys("Bangalore");
     Thread.sleep(2000);
     to.sendKeys(Keys.SHIFT,Keys.chord(Keys.TAB));
     WebElement from=driver.findElementByXPath("//input[@id='src']");
     from.sendKeys("Chennai");
     Thread.sleep(4000);
     to.sendKeys(Keys.CONTROL,Keys.chord(Keys.TAB));
     driver.findElementByXPath("//ul[@class='autoFill']/li").click();
     LocalDate date=LocalDate.now();
     System.out.println("date="+date);
     Month currentmonth=date.getMonth();
     System.out.println("currentmonth="+currentmonth);
     Month nextmonth=currentmonth.plus(1);
     System.out.println("nextmonth="+nextmonth);
     String nm=nextmonth.toString();
     System.out.println("nm="+nm);
     String nm1=nm.substring(0, 3);
     System.out.println("nm1="+nm1);
     String firstlett=nm1.substring(0,1);
     String nm2=nm1.substring(1).toLowerCase();
     System.out.println("nm2="+nm2);
     String conmon=firstlett+nm2;
     System.out.println("conmon="+conmon);
     WebElement tab1=driver.findElementByXPath("//div[@id='rb-calendar_onward_cal']/table");
	 List<WebElement> row=tab1.findElements(By.tagName("tr"));
	 List<WebElement> column=tab1.findElements(By.tagName("td"));
	 int i=1;
     try {
	 do {
	 String actualmonth=column.get(1).getText();
	 String actual=actualmonth.replaceAll("\\d", "");
     System.out.println("actualmonth="+actualmonth);
     System.out.println("actual="+actual);
     if(actual.equals(conmon)) {
    	 System.out.println("yes month matches");
    	 break;
     }
     WebElement button=driver.findElementByXPath("//button[text()='>']");
     WebDriverWait wait=new WebDriverWait(driver,10);
     wait.until(ExpectedConditions.elementToBeClickable(button));
     button.click();
     Thread.sleep(3000);
     i++;
     }while(i<=12);
     }catch(Exception e) {
    	 System.out.println("stale element exception");
     }
     String firstdayofmonday=driver.findElementByXPath("(//th[text()='Mo']/following::td)[1]").getAttribute("class");
     System.out.println("firstdayofmonday="+firstdayofmonday);
     if(firstdayofmonday.contains("empty day")) {
    	 driver.findElementByXPath("(//th[text()='Mo']/following::td)[8]").click();
     }else {
    	 driver.findElementByXPath("(//th[text()='Mo']/following::td)[1]").click();
     }
     driver.findElementByXPath("//button[@id='search_btn']").click();
     WebElement flash=driver.findElementByXPath("(//div[@class='overlay-container']/div)[1]");
     WebDriverWait wait1=new WebDriverWait(driver,10);
     wait1.until(ExpectedConditions.elementToBeClickable(flash));
     flash.click();
     String buscount=driver.findElementByXPath("//span[@class='f-bold busFound']").getText();
	 System.out.println("buscount="+buscount);
	 String count=buscount.replaceAll("\\D", "");
	 System.out.println("count="+count);
	 driver.findElementByXPath("//label[@for='bt_SLEEPER']").click();
	 String seats=driver.findElementByXPath("(//div[@class='seat-left m-top-30'])[1]").getText();
	 System.out.println("seats="+seats);
	 String price=driver.findElementByXPath("(//div[@class='seat-fare ']//span)[1]").getText();
	 System.out.println("price="+price);
	 WebElement viewseats=driver.findElementByXPath("(//div[text()='View Seats'])[1]");
	 Actions builder =new Actions(driver);
	 builder.moveToElement(viewseats).perform();
	 driver.findElementByXPath("(//span[text()='Bus Photos'])[1]").click();
	 
	 for(int j=1;j<=15;j++) {
	 WebElement img=driver.findElementByXPath("(//img[@class='bus-image-new'])["+j+"]");
	 Actions builder1=new Actions(driver);
	 builder1.moveToElement(img).perform();
	 File src=driver.getScreenshotAs(OutputType.FILE);
	 File des=new File("./snaps/redbus/redbus"+j+".png");
	 FileUtils.copyFile(src, des);
	 Thread.sleep(2000);
	 driver.findElementByXPath("(//button[@type='button'])[2]").click();
	 }
	}
}
	


