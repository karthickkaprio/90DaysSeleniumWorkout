package nov.week4.POM;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Date_25 {

public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.edge.driver", "./driver/msedgedriver.exe");
	EdgeOptions option=new EdgeOptions();
	option.setCapability("disable-notifications", true);
	EdgeDriver driver=new EdgeDriver(option);
	driver.get("https://www.lenskart.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	WebElement computer=driver.findElementByXPath("//a[text()='Computer Glasses']");
    Actions builder=new Actions(driver);
    builder.moveToElement(computer).perform();
    WebElement men=driver.findElementByXPath("(//div[@class='gender_info'])[4]");
    builder.moveToElement(men).perform();
    driver.findElementByXPath("(//div[@class='category-menu_data category active'])[3]").click();
    WebElement round=driver.findElementByXPath("//span[@title='Round']");
    WebDriverWait wait=new WebDriverWait(driver,10);
    wait.until(ExpectedConditions.elementToBeClickable(round));
    round.click();
    Thread.sleep(2000);
    TreeMap<Integer,String> tm=new TreeMap<Integer,String>();
    String framecolor1,colour,colour1,cou,num1,col,displayedresult,display,totalresult;
    int count,num;
    try {
    for(int i=1;i<=11;i++) {
    WebElement framecolor=driver.findElementByXPath("(//li[@class='list-checkbox']//span)["+i+"]");
    WebDriverWait wait1=new WebDriverWait(driver,10);
    wait1.until(ExpectedConditions.elementToBeClickable(framecolor));
    Actions builder1=new Actions(driver);
    builder1.moveToElement(framecolor).perform();
    framecolor1=framecolor.getText();
    colour=framecolor1.replaceAll("\\d", "");
    colour1=colour.replaceAll("\\(", "").replaceAll("\\)", "");
    cou=framecolor1.replaceAll("\\D", "");
    count=Integer.parseInt(cou);
    tm.put(count, colour1);
    Thread.sleep(1000);
    }
    }catch(Exception e) {
    	System.out.println("move target out of bound exception");
    }
    for (Map.Entry map : tm.entrySet()) {
	System.out.println(map.getKey()+" "+map.getValue());
	}
    num=tm.lastKey();
    num1=Integer.toString(num);
    col=tm.get(num);
    WebElement highcount=driver.findElementByXPath("//span[text()='"+col+"("+num1+")']");
    Actions builder2=new Actions(driver);
    builder2.moveToElement(highcount).perform();
    highcount.click();
    Thread.sleep(2000);
    WebElement result=driver.findElementByXPath("//div[@class='show_count']");
    wait.until(ExpectedConditions.elementToBeClickable(result));
    displayedresult=result.getText();
    display=displayedresult.replaceAll("\\D", "");
    totalresult=display.substring(1);
    if(num1.contains(totalresult)) {
    	System.out.println("yes confirmed framecolourcount matches the displaycount");
    }else{
    	System.err.println("framecolourcount not matches the displaycount");
    }
    int quoitent,quo;
    quoitent=num/3;
    quo=Math.round(quoitent);
    System.out.println("quo="+quo);
    List<String> li=new ArrayList<String>();
    for(int i=1;i<=quo;i++) {
    	for(int j=1;j<=3;j++) {
    WebElement product=driver.findElementByXPath("(//div[@unbxdparam_prank='"+i+"'])["+j+"]");
    WebDriverWait wait3=new WebDriverWait(driver,10);
    wait3.until(ExpectedConditions.elementToBeClickable(product));
    Actions builder3=new Actions(driver);
    builder3.moveToElement(product).perform();
    Thread.sleep(2000);
    WebElement size=driver.findElementByXPath("(//*[@unbxdparam_prank='"+i+"']/div/div/div/div/p/span)["+j+"]");
    String sizes=size.getText();
    li.add(sizes);
    	}
    }
    int smallcount=0,mediumcount=0,largecount=0,empty=0;
    for(String siz:li) {
    	if(siz.equalsIgnoreCase("small")) {
    		smallcount=smallcount+1;
    	}
    	else if(siz.equalsIgnoreCase("medium")) {
    		mediumcount=mediumcount+1;
    	}
    	else if(siz.equalsIgnoreCase("large")) {
    		largecount=largecount+1;
    	}
    	else {
    		empty=empty+1;
    	}
    }
    System.out.println("frame smallsize="+smallcount);
    System.out.println("frame mediumsize="+mediumcount);
    System.out.println("frame largesize="+largecount);
    System.out.println("frame emptysize="+empty);
    }
}

