package nov.week4.POM;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_23 {

	public static void main(String[] args) throws InterruptedException {
	WebDriverManager.firefoxdriver().setup();
	//ChromeOptions option=new ChromeOptions();
	//option.addArguments("--incognito");
	FirefoxDriver driver=new FirefoxDriver();
	driver.get("https://www.myntra.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	Dimension win=driver.manage().window().getSize();
	System.out.println("windowdimension="+win);
    driver.findElementByXPath("//div[@class='desktop-query']/input").sendKeys("sunglasses",Keys.ENTER);
    WebElement polaroid=driver.findElementByXPath("(//input[@value='Polaroid']/following::div)[1]");
	WebDriverWait wait=new WebDriverWait(driver,10);
	wait.until(ExpectedConditions.elementToBeClickable(polaroid));
	polaroid.click();
	Thread.sleep(2000);
	driver.findElementByXPath("(//ul[@class='gender-list']//label)[1]").click();
	Thread.sleep(4000);
	//WebElement menrectangle=driver.findElementByXPath("(//h4[text()='Men Rectangle Sunglasses'])[1]");
	//Actions builder=new Actions(driver);
	//builder.moveToElement(menrectangle).perform();
	WebElement size=driver.findElementByXPath("(//h4[text()='Men Rectangle Sunglasses']/following::span)[1]");
	JavascriptExecutor exe=(JavascriptExecutor)driver;
	exe.executeScript("arguments[0].scrollIntoView(true);",size);
	String size1=size.getText();
	System.out.println("size="+size1);
	
	}

}
