package dec.week1.POM;

import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_1 {

	public static void main(String[] args) throws InterruptedException {
	 WebDriverManager.chromedriver().setup();
	 ChromeOptions option=new ChromeOptions();
	 //option.addArguments("--headless");
	 option.setCapability("--disable-notifications", true);
	 //option.setHeadless(true);
	 ChromeDriver driver=new ChromeDriver(option);
	 driver.get("https://www.zomato.com/chennai");
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	 //String title=driver.getTitle();
	 //System.out.println("title="+title);
	 //String page=driver.getPageSource();
	 //System.out.println("page="+page);
	 /*WebDriverWait wait=new WebDriverWait(driver,10);
	 WebElement cookie=driver.findElementByXPath("//div[@class='sc-eXEjpC leDuYq']/i");
	 wait.until(ExpectedConditions.elementToBeClickable(cookie));
	 cookie.click();*/
	 WebDriverWait wait1=new WebDriverWait(driver,10);
	 WebElement dropbox=driver.findElementByXPath("//*[name()='svg']//*[name()='title' and text()='down-triangle']/ancestor::i");
	 wait1.until(ExpectedConditions.elementToBeClickable(dropbox));
	 dropbox.click();
	 driver.findElementByXPath("//p[text()='Velachery, Chennai']/parent::div").click();
	 WebDriverWait wait2=new WebDriverWait(driver,10);
	 WebElement search=driver.findElementByXPath("(//*[name()='svg']//*[name()='title' and text()='Search']/preceding::input)[2]");
	 wait2.until(ExpectedConditions.elementToBeClickable(search));
	 search.sendKeys("A2B-Adyar Ananda",Keys.ENTER);
	 Actions builder=new Actions(driver);
	 builder.moveToElement(search).perform();
	 search.click();
	 WebDriverWait wait3=new WebDriverWait(driver,10);
     WebElement last=driver.findElementByXPath("(//p[text()='A2B - Adyar Ananda Bhavan']/parent::div)[last()]");
     wait3.until(ExpectedConditions.elementToBeClickable(last));
     last.click();
     WebElement orderonline=driver.findElementByXPath("//a[text()='Order Online']");
     wait2.until(ExpectedConditions.elementToBeClickable(orderonline));
     builder.moveToElement(orderonline).perform();
     JavascriptExecutor exe=(JavascriptExecutor)driver;
     exe.executeScript("arguments[0].click();", orderonline);
     try {
     String status=driver.findElementByXPath("//div[@class='subtitle']").getText();
     System.out.println("status of restuarant="+status);
     }catch(Exception e) {
    	 System.out.println("yes the restuarant is open now");
     }
     int mustry=1;
     System.out.println("The number of mustry items listed");
     for(int i=1;i<=11;i++) {
     WebElement st=driver.findElementByXPath("(//div[text()='MUST TRY']/preceding::h4)["+i+"]");
     Actions build=new Actions(driver);
     build.moveToElement(st).perform();
     String sweet=st.getText();
     System.out.println(mustry+" "+sweet);
     mustry=mustry+1;
     }
     //driver.findElementByXPath("//p[text()='Sweets (11)']").click();
     TreeMap<Double,String> tm=new TreeMap<Double,String>();
     String sname,cost1,cost2;
     for(int i=101;i<=111;i++) {
    	 WebElement sweetname=driver.findElementByXPath("(//h4[@class='sc-1s0saks-16 ezKciv'])["+i+"]");
         Actions builder2=new Actions(driver);
         builder2.moveToElement(sweetname).perform();
    	 sname=sweetname.getText();
         WebElement cost=driver.findElementByXPath("(//h4[@class='sc-1s0saks-16 ezKciv'])["+i+"]/following::span");
         cost1=cost.getText();
         cost2=cost1.substring(1);
         double scost=Double.parseDouble(cost2);
         tm.put(scost, sname);
     }	 
	 for (Map.Entry map : tm.entrySet()) {
		 System.out.println(map.getKey()+" "+map.getValue());
		}
	 double key=tm.lastKey();
	 String costlysweet=tm.get(key);
	 System.out.println("costlysweet="+costlysweet);
	 driver.findElementByXPath("//a[text()='Photos']/parent::span").click();
	 
	 WebElement actualcount=driver.findElementByXPath("(//div[@class='sc-ecFaGM Clcyf']/div)[1]");
	 wait2.until(ExpectedConditions.elementToBeClickable(actualcount));
	 String actualcount1=actualcount.getText();
	 String actual=actualcount1.replaceAll("\\D", "");
	 String acount=actual.substring(1,3);
	 int acount1=Integer.parseInt(acount);
	 int count=1;
	 for(int i=1;i<=acount1;i++) {
	 WebElement photo=driver.findElementByXPath("(//div[@class='sc-etRtft eeVMwg']//img)["+i+"]");
	 Actions builder4=new Actions(driver);
	 builder4.moveToElement(photo).perform();
	 if(count==acount1) {
	 System.out.println("yes image matches with the count shown");
	 break;
	 }
	 count=count+1;
	 }
	 
     }

}
