package dec.week1.POM;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_2 {

	public static void main(String[] args) throws InterruptedException, Exception {
	WebDriverManager.chromedriver().setup();
	ChromeOptions option=new ChromeOptions();
	option.addArguments("--disable-notifications");
	ChromeDriver driver=new ChromeDriver(option);
	driver.get("https://www.gap.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	WebElement flash=driver.findElementByXPath("//button[@aria-label='close email sign up modal']");
	WebDriverWait wait=new WebDriverWait(driver,15);
	wait.until(ExpectedConditions.elementToBeClickable(flash));
	flash.click();
	driver.findElementByXPath("//a[text()='Gap Factory']").click();
	WebElement flash1=driver.findElementByXPath("//button[@aria-label='close email sign up modal']");
	WebDriverWait wt=new WebDriverWait(driver,10);
	wt.until(ExpectedConditions.elementToBeClickable(flash1));
	flash1.click();
	Thread.sleep(2000);
    WebElement newarrival=driver.findElementByXPath("(//ul[@class='heading-e topnav']//button)[1]");
    WebDriverWait wait11=new WebDriverWait(driver,10);
    wait11.until(ExpectedConditions.elementToBeClickable(newarrival));
    Actions build=new Actions(driver);
	build.clickAndHold(newarrival).perform();
    WebElement babygirl=driver.findElementByXPath("//span[text()='Baby Girl']");
	JavascriptExecutor exe=(JavascriptExecutor)driver;
	exe.executeScript("arguments[0].click();", babygirl);
	WebElement shopbysize=driver.findElementByXPath("(//a[text()='Baby Girl Shop by Size'])[1]");
	WebDriverWait wait2=new WebDriverWait(driver,10);
	wait2.until(ExpectedConditions.elementToBeClickable(shopbysize));
	shopbysize.click();
	WebElement totalitem=driver.findElementByXPath("//div[@aria-live='polite']");
	WebDriverWait wait3=new WebDriverWait(driver,10);
	wait3.until(ExpectedConditions.elementToBeClickable(totalitem));
	String totalitems=totalitem.getText();
	System.out.println("total items="+totalitems);
	String total=totalitems.replaceAll("\\D", "");
	int items=Integer.parseInt(total);
	int count=1;
	for(int i=1;i<=items;i++) {
	WebElement img=driver.findElementByXPath("(//div[@class='product-card']//img)["+i+"]");
	WebDriverWait wait4=new WebDriverWait(driver,10);
	wait4.until(ExpectedConditions.elementToBeClickable(img));
	Actions builder2=new Actions(driver);
	builder2.moveToElement(img).perform();
	count=count+1;
	if(i==300) {
		try{
		WebElement next=driver.findElementByXPath("//button[@aria-label='Next Page']");
		WebDriverWait wait5=new WebDriverWait(driver,10);
		wait5.until(ExpectedConditions.elementToBeClickable(next));
		Thread.sleep(4000);
		JavascriptExecutor exe1=(JavascriptExecutor)driver;
        exe1.executeScript("arguments[0].click();", next);
		next.click();
		}catch(Exception e) {
			System.out.println("stale element reference exception");
		}
		i=1;
	}
	else if(items==count) {
		System.out.println("productcount"+'\t'+"totalitems");
		System.out.println(count+'\t'+items);
		System.out.println("yes total items matches with the resulting product count");
        break;	
	}
}
	WebElement category=driver.findElementByXPath("//button[@aria-label='category filter options dropdown']");
	WebDriverWait wait6=new WebDriverWait(driver,10);
	wait6.until(ExpectedConditions.elementToBeClickable(category));
	Actions builder5=new Actions(driver);
	builder5.moveToElement(category).perform();
	category.click();
	WebElement pantsandjeans=driver.findElementByXPath("//input[@aria-label='Pants & Jeans']");
	builder5.moveToElement(pantsandjeans).perform();
	JavascriptExecutor exe2=(JavascriptExecutor)driver;
    exe2.executeScript("arguments[0].click();", pantsandjeans);
	Thread.sleep(2000);
	category.click();
	WebElement img1=driver.findElementByXPath("(//div[@class='product-card']//img)[1]");
	WebDriverWait wait7=new WebDriverWait(driver,10);
	wait7.until(ExpectedConditions.elementToBeClickable(img1));
	img1.click();
	try {
	WebElement flash2=driver.findElementByXPath("//button[@aria-label='close email sign up modal']");
	WebElement discount=driver.findElementByXPath("//div[@class='promoDrawer__handlebar__icon']");
	WebDriverWait wait8=new WebDriverWait(driver,20);
	wait8.until(ExpectedConditions.elementToBeClickable(flash2));
	flash2.click();
	wait8.until(ExpectedConditions.elementToBeClickable(discount));
	discount.click();
	}catch(Exception fl) {
	    System.out.println("no flash present");	
	}
	try {
	WebElement frm=driver.findElementByXPath("//div[@id='kampyleFormModal']/iframe");
	WebDriverWait wait12=new WebDriverWait(driver,10);
	wait12.until(ExpectedConditions.elementToBeClickable(frm));
	driver.switchTo().frame(frm);
	driver.findElementByXPath("//button[@aria-label='Exit']/i").click();
	driver.switchTo().defaultContent();
    }catch(Exception f) {
        System.out.println("no such frame present");
    }
	WebElement size=driver.findElementByXPath("//span[text()='6-12 M']");
	WebDriverWait wait10=new WebDriverWait(driver,10);
	wait10.until(ExpectedConditions.elementToBeClickable(size));
	size.click();
	Thread.sleep(2000);
	String producttitle,confirmproduct,actualprice,actual,reducedprice,reduced;
	float act,red,discountamount;
	producttitle=driver.findElementByXPath("//div[@class='product-title']/h1").getText();
	driver.findElementByXPath("//button[@class='add-to-bag']").click();
	Thread.sleep(3000);
	confirmproduct=driver.findElementByXPath("(//div[@id='modalWindow']//h4)[1]").getText();
	Assert.assertEquals(producttitle, confirmproduct);
	System.out.println("yes product verified");
	actualprice=driver.findElementByXPath("(//div[@id='modalWindow']//h4)[2]").getText();
	actual=actualprice.substring(1);
	act=Float.parseFloat(actual);
	reducedprice=driver.findElementByXPath("((//div[@id='modalWindow']//h4)[3]/span)[2]").getText();
	reduced=reducedprice.substring(1);
	red=Float.parseFloat(reduced);
	discountamount=act-red;
	System.out.println("discount amount=$"+discountamount);
	
	
	}
}
