package dec.week1.POM;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date_3 {

	public static void main(String[] args) throws InterruptedException {
	WebDriverManager.chromedriver().setup();
	ChromeOptions option=new ChromeOptions();
	option.addArguments("--disable-notifications");
	ChromeDriver driver=new ChromeDriver(option);
	driver.get("https://www.nykaa.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElementByXPath("//input[@id='SearchInputBox']").sendKeys("perfumes",Keys.ENTER);
	WebDriverWait wait=new WebDriverWait(driver,10);
	WebElement showing=driver.findElementByXPath("//div[@class='col-md-12']/div");
	wait.until(ExpectedConditions.elementToBeClickable(showing));
	String showingresult=showing.getText();
	String result=showingresult.replaceAll("\\D", "").substring(0,2);
	int res=Integer.parseInt(result);
	System.out.println("res="+res);
	TreeMap<Integer,String> tm=new TreeMap<Integer,String>();
	for(int i=1;i<=60;i++) {
	WebDriverWait wt=new WebDriverWait(driver,10);
	WebElement productname=driver.findElementByXPath("(//div[@class='col-xs-12']//h2)["+i+"]");
	wt.until(ExpectedConditions.elementToBeClickable(productname));
	Actions builder=new Actions(driver);
	builder.moveToElement(productname).perform();
	String name=productname.getText();
	String price=driver.findElementByXPath("((//div[@class='price-info'])["+i+"]/span)[2]").getText();
	String ru=price.substring(1);
	int rupee=Integer.parseInt(ru);
	tm.put(rupee, name);
	}
    for (Map.Entry map : tm.entrySet()) {
        System.out.println(map.getKey()+" "+map.getValue());
    }
    int highestkey=tm.lastKey();
	System.out.println("highestkey="+highestkey);
	String product=tm.get(highestkey);
    WebElement pro=driver.findElementByXPath("//span[text()='"+product+"']");
    wait.until(ExpectedConditions.elementToBeClickable(pro));
    JavascriptExecutor exe=(JavascriptExecutor)driver;
    exe.executeScript("arguments[0].click();", pro);
    Set<String> allwin=driver.getWindowHandles();
    List<String> win=new ArrayList<String>(allwin);
    String parent=win.get(0);
    String child=win.get(1);
    driver.switchTo().window(child);
    WebElement button=driver.findElementByXPath("//div[@class='pull-left']//button");
    wait.until(ExpectedConditions.elementToBeClickable(button));
    button.click();
    WebElement verifymessage=driver.findElementByXPath("(//div[@class='mm-text']//span)[2]");
	wait.until(ExpectedConditions.elementToBeClickable(verifymessage));
	System.out.println("confirmation message="+verifymessage.getText());
	driver.findElementByXPath("(//div[@class='AddToBagbox']//div)[2]").click();
	WebElement gtotal=driver.findElementByXPath("//div[@class='value medium-strong']");
	String grandtotal=gtotal.getText();
	System.out.println("grand total of product="+grandtotal);
	WebElement proceed=driver.findElementByXPath("//i[@class='proceed-arrow']//*[name()='svg']");
	WebDriverWait pwait=new WebDriverWait(driver,20);
	pwait.until(ExpectedConditions.elementToBeClickable(proceed));
	Actions builder1=new Actions(driver);
	builder1.moveToElement(proceed).perform();
	JavascriptExecutor exe1=(JavascriptExecutor)driver;
    exe1.executeScript("arguments[0].click();", proceed);
	WebElement guest=driver.findElementByXPath("(//i[@class='proceed-arrow']//*[name()='svg'])[2]");
	wait.until(ExpectedConditions.elementToBeClickable(guest));
	Actions builder2=new Actions(driver);
	builder2.moveToElement(proceed).perform();
	JavascriptExecutor exe2=(JavascriptExecutor)driver;
    exe2.executeScript("arguments[0].click();", guest);
	Thread.sleep(2000);
	driver.findElementByXPath("//input[@name='name']").sendKeys("kumar");
	driver.findElementByXPath("//input[@name='email']").sendKeys("kumar123@gmail.com");
	driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys("9449546382");
	driver.findElementByXPath("//input[@name='pinCode']").sendKeys("688001");
	driver.findElementByXPath("//textarea[@class='textarea-control prl10']").sendKeys("kerala");
	driver.findElementByXPath("(//*[name()='svg' and @xmlns='http://www.w3.org/2000/svg']//*[name()='path' and @fill='#fff'])[1]").click();
	WebElement paynow=driver.findElementByXPath("//button[@class='btn fill full big proceed']");
	wait.until(ExpectedConditions.elementToBeClickable(paynow));
	paynow.click();
	Thread.sleep(2000);
	String error=driver.findElementByXPath("//div[@class='form-field  error']/span").getText();
	System.out.println("error="+error);
	}
}

